<template>
  <div
    v-if="show && todo"
    data-testid="change-cover-modal"
    class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-200"
  >
    <div
      class="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden transform transition-all"
      @click.stop
    >
      <div class="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
        <div class="flex items-center gap-2.5">
          <div class="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
            <ImagePlus :size="18" :stroke-width="2.5" />
          </div>
          <h3 class="text-base font-bold text-slate-800">Ubah Cover Todo</h3>
        </div>
        <button
          type="button"
          data-testid="close-cover-modal-btn"
          @click="onClose"
          class="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
        >
          <X :size="18" />
        </button>
      </div>

      <form @submit.prevent="handleSave" class="p-6 space-y-4">
        <div>
          <label class="block text-sm font-semibold text-slate-700 mb-2">
            Pilih Gambar Cover
          </label>
          <label class="flex flex-col items-center justify-center w-full h-44 border-2 border-dashed border-slate-300 hover:border-indigo-500 rounded-2xl cursor-pointer bg-slate-50/50 hover:bg-indigo-50/20 transition-all overflow-hidden relative">
            <img
              v-if="previewUrl"
              :src="previewUrl"
              alt="Preview"
              class="w-full h-full object-cover"
            />
            <div v-else class="flex flex-col items-center justify-center pt-5 pb-6 text-center px-4">
              <div class="w-10 h-10 mb-2 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <Upload :size="20" />
              </div>
              <p class="text-sm font-semibold text-slate-700">
                Klik untuk memilih foto
              </p>
              <p class="text-xs text-slate-500 mt-1">PNG, JPG, JPEG (Max. 1MB)</p>
            </div>
            <input
              type="file"
              data-testid="cover-file-input"
              accept=".jpg,.jpeg,.png"
              @change="handleFileChange"
              class="hidden"
            />
          </label>
        </div>

        <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            data-testid="cancel-cover-modal-btn"
            @click="onClose"
            :disabled="loading"
            class="px-4 py-2.5 text-sm font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors"
          >
            Batal
          </button>
          <button
            type="submit"
            data-testid="submit-cover-modal-btn"
            :disabled="loading"
            class="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-sky-600 hover:bg-sky-700 active:bg-sky-800 rounded-xl shadow-md shadow-sky-600/25 transition-all disabled:opacity-60"
          >
            <template v-if="loading">
              <Loader2 :size="18" class="animate-spin" />
              <span>Mengunggah...</span>
            </template>
            <template v-else>
              <Upload :size="18" :stroke-width="2.5" />
              <span>Unggah Cover</span>
            </template>
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from "vue";
import { ImagePlus, X, Loader2, Upload } from "lucide-vue-next";
import { useTodosStore } from "../states/todosStore";
import { showErrorDialog } from "../../../helpers/toolsHelper";
import type { Todo } from "../api/todoApi";

interface ChangeCoverModalProps {
  show?: boolean;
  todo?: Todo | null;
}

const props = withDefaults(defineProps<ChangeCoverModalProps>(), {
  show: false,
  todo: null,
});

const emit = defineEmits<{
  (e: "close"): void;
}>();

const todosStore = useTodosStore();

const loading = ref(false);
const fileCover = ref<File | null>(null);
const previewUrl = ref<string | null>(null);

function onClose() {
  emit("close");
}

watch(
  () => props.show,
  (newShow) => {
    if (newShow) {
      document.body.style.overflow = "hidden";
      fileCover.value = null;
      previewUrl.value = null;
    } else {
      document.body.style.overflow = "auto";
    }
  }
);

watch(
  () => [todosStore.isTodoChangeCover, todosStore.isTodoChangedCover],
  ([isTodoChangeCover, isTodoChangedCover]) => {
    if (isTodoChangeCover) {
      todosStore.setIsTodoChangeCover(false);
      loading.value = false;
      if (isTodoChangedCover) {
        todosStore.setIsTodoChangedCover(false);
        todosStore.asyncSetTodo(props.todo?.id);
        onClose();
      }
    }
  }
);

function handleFileChange(e: Event) {
  const target = e.target as HTMLInputElement;
  const file = target?.files?.[0];
  if (file) {
    const allowedTypes = ["image/jpeg", "image/jpg", "image/png"];
    if (!allowedTypes.includes(file.type)) {
      showErrorDialog("Hanya file JPEG, JPG, atau PNG yang diperbolehkan!");
      return;
    }
    const MAX_FILE_SIZE = 1024 * 1024; // 1MB sesuai batas server
    if (file.size > MAX_FILE_SIZE) {
      showErrorDialog("Ukuran file terlalu besar. Maksimal 1MB!");
      return;
    }
    fileCover.value = file;
    previewUrl.value = URL.createObjectURL(file);
  }
}

function handleSave() {
  if (!fileCover.value) {
    showErrorDialog("Pilih file cover terlebih dahulu!");
    return;
  }

  loading.value = true;
  todosStore.asyncSetIsTodoChangeCover(props.todo.id, fileCover.value);
}
</script>
