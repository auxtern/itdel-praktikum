import { defineStore } from "pinia";
import todoApi, { type Todo } from "../api/todoApi";
import { showErrorDialog, showSuccessDialog } from "../../../helpers/toolsHelper";

export interface TodosState {
  todos: Todo[];
  todo: Todo | null;
  isTodo: boolean;
  isTodoAdd: boolean;
  isTodoAdded: boolean;
  isTodoChange: boolean;
  isTodoChanged: boolean;
  isTodoChangeCover: boolean;
  isTodoChangedCover: boolean;
  isTodoDelete: boolean;
  isTodoDeleted: boolean;
}

export const useTodosStore = defineStore("todos", {
  state: (): TodosState => ({
    todos: [],
    todo: null,
    isTodo: false,
    isTodoAdd: false,
    isTodoAdded: false,
    isTodoChange: false,
    isTodoChanged: false,
    isTodoChangeCover: false,
    isTodoChangedCover: false,
    isTodoDelete: false,
    isTodoDeleted: false,
  }),
  actions: {
    setTodos(todos: Todo[]) {
      this.todos = todos;
    },
    setTodo(todo: Todo | null) {
      this.todo = todo;
    },
    setIsTodo(status: boolean) {
      this.isTodo = status;
    },
    setIsTodoAdd(status: boolean) {
      this.isTodoAdd = status;
    },
    setIsTodoAdded(status: boolean) {
      this.isTodoAdded = status;
    },
    setIsTodoChange(status: boolean) {
      this.isTodoChange = status;
    },
    setIsTodoChanged(status: boolean) {
      this.isTodoChanged = status;
    },
    setIsTodoChangeCover(status: boolean) {
      this.isTodoChangeCover = status;
    },
    setIsTodoChangedCover(status: boolean) {
      this.isTodoChangedCover = status;
    },
    setIsTodoDelete(status: boolean) {
      this.isTodoDelete = status;
    },
    setIsTodoDeleted(status: boolean) {
      this.isTodoDeleted = status;
    },
    async asyncSetTodos(is_finished: string | number = "") {
      try {
        const todos = await todoApi.getTodos(is_finished);
        this.setTodos(todos);
      } catch (error) {
        this.setTodos([]);
      }
    },
    async asyncSetTodo(todoId: string | number) {
      try {
        const todo = await todoApi.getTodoById(todoId);
        this.setTodo(todo);
      } catch (error) {
        this.setTodo(null);
      } finally {
        this.setIsTodo(true);
      }
    },
    async asyncSetIsTodoAdd(title: string, description: string) {
      try {
        await todoApi.postTodo(title, description);
        showSuccessDialog("Todo berhasil ditambahkan!");
        this.setIsTodoAdded(true);
      } catch (error: any) {
        showErrorDialog(error.message);
        this.setIsTodoAdded(false);
      } finally {
        this.setIsTodoAdd(true);
      }
    },
    async asyncSetIsTodoChange(
      todoId: string | number,
      title: string,
      description: string,
      is_finished: boolean | number
    ) {
      try {
        const message = await todoApi.putTodo(
          todoId,
          title,
          description,
          is_finished
        );
        showSuccessDialog(message || "Todo berhasil diperbarui!");
        this.setIsTodoChanged(true);
      } catch (error: any) {
        showErrorDialog(error.message);
        this.setIsTodoChanged(false);
      } finally {
        this.setIsTodoChange(true);
      }
    },
    async asyncSetIsTodoChangeCover(
      todoId: string | number,
      cover: File | (Blob & { name?: string })
    ) {
      try {
        const message = await todoApi.postTodoCover(todoId, cover);
        showSuccessDialog(message || "Cover berhasil diperbarui!");
        this.setIsTodoChangedCover(true);
      } catch (error: any) {
        showErrorDialog(error.message);
        this.setIsTodoChangedCover(false);
      } finally {
        this.setIsTodoChangeCover(true);
      }
    },
    async asyncSetIsTodoDelete(todoId: string | number) {
      try {
        const message = await todoApi.deleteTodo(todoId);
        showSuccessDialog(message || "Todo berhasil dihapus!");
        this.setIsTodoDeleted(true);
      } catch (error: any) {
        showErrorDialog(error.message);
        this.setIsTodoDeleted(false);
      } finally {
        this.setIsTodoDelete(true);
      }
    },
  },
});
