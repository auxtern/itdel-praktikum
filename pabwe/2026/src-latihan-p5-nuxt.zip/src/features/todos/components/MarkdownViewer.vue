<template>
  <div ref="viewerContainer" class="toastui-editor-viewer-wrapper" data-testid="markdown-viewer"></div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch, onBeforeUnmount } from "vue";
import Viewer from "@toast-ui/editor/dist/toastui-editor-viewer";
import "@toast-ui/editor/dist/toastui-editor-viewer.css";

interface MarkdownViewerProps {
  content?: string;
}

const props = withDefaults(defineProps<MarkdownViewerProps>(), {
  content: "",
});

const viewerContainer = ref<HTMLElement | null>(null);
let viewerInstance: any = null;

onMounted(() => {
  viewerInstance = new Viewer({
    el: viewerContainer.value,
    initialValue: props.content || "",
  });
});

watch(
  () => props.content,
  (newContent) => {
    viewerInstance.setMarkdown(newContent || "");
  }
);

onBeforeUnmount(() => {
  viewerInstance.destroy();
  viewerInstance = null;
});
</script>

<style>
.toastui-editor-viewer-wrapper .toastui-editor-contents {
  font-family: inherit;
  font-size: 0.95rem;
  color: #475569;
}
</style>
