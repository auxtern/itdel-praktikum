export const DELCOM_BASEURL =
  process.env.NEXT_PUBLIC_DELCOM_BASEURL || "http://localhost:8765/api/v1";
