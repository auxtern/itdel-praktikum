import { Routes } from '@angular/router';
import { AuthLayoutComponent } from './features/auth/layouts/auth-layout/auth-layout.component';
import { LoginPageComponent } from './features/auth/pages/login-page/login-page.component';
import { RegisterPageComponent } from './features/auth/pages/register-page/register-page.component';
import { TodoLayoutComponent } from './features/todos/layouts/todo-layout/todo-layout.component';
import { HomePageComponent } from './features/todos/pages/home-page/home-page.component';
import { DetailPageComponent } from './features/todos/pages/detail-page/detail-page.component';
import { UsersPageComponent } from './features/users/pages/users-page/users-page.component';
import { ProfilePageComponent } from './features/users/pages/profile-page/profile-page.component';
import { NotFoundPageComponent } from './features/common/pages/not-found-page/not-found-page.component';

export const routes: Routes = [
  {
    path: 'auth',
    component: AuthLayoutComponent,
    children: [
      { path: 'login', component: LoginPageComponent },
      { path: 'register', component: RegisterPageComponent },
      { path: '', redirectTo: 'login', pathMatch: 'full' },
    ],
  },
  {
    path: '',
    component: TodoLayoutComponent,
    children: [
      { path: '', component: HomePageComponent },
      { path: 'todos/:todoId', component: DetailPageComponent },
      { path: 'users', component: UsersPageComponent },
      { path: 'profile', component: ProfilePageComponent },
    ],
  },
  {
    path: '**',
    component: NotFoundPageComponent,
  },
];
