import { Injectable, signal } from '@angular/core';
import ApiHelper, { BASE_URL } from '../../../helpers/api.helper';
import { showErrorDialog, showSuccessDialog } from '../../../helpers/tools.helper';
import type { Todo } from '../models/todo.model';

@Injectable({
  providedIn: 'root',
})
export class TodosService {
  private todosUrl = `${BASE_URL}/todos`;

  todos = signal<Todo[]>([]);
  todo = signal<Todo | null>(null);
  isTodo = signal<boolean>(false);
  isTodoAdd = signal<boolean>(false);
  isTodoAdded = signal<boolean>(false);
  isTodoChange = signal<boolean>(false);
  isTodoChanged = signal<boolean>(false);
  isTodoChangeCover = signal<boolean>(false);
  isTodoChangedCover = signal<boolean>(false);
  isTodoDelete = signal<boolean>(false);
  isTodoDeleted = signal<boolean>(false);

  async postTodo(title: string, description: string): Promise<any> {
    const response = await ApiHelper.fetchData(`${this.todosUrl}/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, description }),
    });
    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal menambahkan todo');
    }
    return result.data;
  }

  async postTodoCover(todoId: string | number, cover: File): Promise<string> {
    const formData = new FormData();
    formData.append('cover', cover, cover.name || 'cover.jpg');
    const response = await ApiHelper.fetchData(`${this.todosUrl}/${todoId}/cover`, {
      method: 'POST',
      body: formData,
    });
    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal mengubah cover');
    }
    return result.message;
  }

  async putTodo(
    todoId: string | number,
    title: string,
    description: string,
    is_finished: boolean | number
  ): Promise<string> {
    const response = await ApiHelper.fetchData(`${this.todosUrl}/${todoId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        description,
        is_finished: is_finished ? 1 : 0,
      }),
    });
    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal mengubah todo');
    }
    return result.message;
  }

  async getTodos(is_finished: string | number | boolean = ''): Promise<Todo[]> {
    const targetUrl =
      is_finished !== '' && is_finished !== null && is_finished !== undefined
        ? `/?is_finished=${is_finished}`
        : '/';
    const response = await ApiHelper.fetchData(`${this.todosUrl}${targetUrl}`, {
      method: 'GET',
    });
    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal mengambil data todo');
    }
    return result.data?.todos || [];
  }

  async getTodoById(todoId: string | number): Promise<Todo> {
    const response = await ApiHelper.fetchData(`${this.todosUrl}/${todoId}`, {
      method: 'GET',
    });
    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal mengambil detail todo');
    }
    return result.data?.todo;
  }

  async deleteTodo(todoId: string | number): Promise<string> {
    const response = await ApiHelper.fetchData(`${this.todosUrl}/${todoId}`, {
      method: 'DELETE',
    });
    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal menghapus todo');
    }
    return result.message;
  }

  async asyncSetTodos(is_finished: string | number | boolean = '') {
    try {
      const todos = await this.getTodos(is_finished);
      this.todos.set(todos);
    } catch {
      this.todos.set([]);
    }
  }

  async asyncSetTodo(todoId: string | number) {
    try {
      const todo = await this.getTodoById(todoId);
      this.todo.set(todo);
    } catch {
      this.todo.set(null);
    } finally {
      this.isTodo.set(true);
    }
  }

  async asyncSetIsTodoAdd(title: string, description: string) {
    try {
      await this.postTodo(title, description);
      showSuccessDialog('Todo berhasil ditambahkan!');
      this.isTodoAdded.set(true);
    } catch (error: any) {
      showErrorDialog(error.message);
      this.isTodoAdded.set(false);
    } finally {
      this.isTodoAdd.set(true);
    }
  }

  async asyncSetIsTodoChange(
    todoId: string | number,
    title: string,
    description: string,
    is_finished: boolean | number
  ) {
    try {
      const message = await this.putTodo(
        todoId,
        title,
        description,
        is_finished
      );
      showSuccessDialog(message || 'Todo berhasil diperbarui!');
      this.isTodoChanged.set(true);
    } catch (error: any) {
      showErrorDialog(error.message);
      this.isTodoChanged.set(false);
    } finally {
      this.isTodoChange.set(true);
    }
  }

  async asyncSetIsTodoChangeCover(todoId: string | number, cover: File) {
    try {
      const message = await this.postTodoCover(todoId, cover);
      showSuccessDialog(message || 'Cover berhasil diperbarui!');
      this.isTodoChangedCover.set(true);
    } catch (error: any) {
      showErrorDialog(error.message);
      this.isTodoChangedCover.set(false);
    } finally {
      this.isTodoChangeCover.set(true);
    }
  }

  async asyncSetIsTodoDelete(todoId: string | number) {
    try {
      const message = await this.deleteTodo(todoId);
      showSuccessDialog(message || 'Todo berhasil dihapus!');
      this.isTodoDeleted.set(true);
    } catch (error: any) {
      showErrorDialog(error.message);
      this.isTodoDeleted.set(false);
    } finally {
      this.isTodoDelete.set(true);
    }
  }
}
