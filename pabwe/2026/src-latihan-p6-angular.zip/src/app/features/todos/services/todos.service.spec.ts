import { describe, it, expect, vi, beforeEach } from 'vitest';
import { TodosService } from './todos.service';
import ApiHelper from '../../../helpers/api.helper';
import Swal from 'sweetalert2';

describe('TodosService', () => {
  let service: TodosService;
  const mockTodo = {
    id: 1,
    title: 'Belajar Angular',
    description: 'Deskripsi todo',
    is_finished: 0,
  };

  beforeEach(() => {
    vi.restoreAllMocks();
    service = new TodosService();
  });

  describe('postTodo', () => {
    it('should return data on success', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', data: { id: 1 } }), { status: 201 })
      );

      const res = await service.postTodo('Title', 'Desc');
      expect(res).toEqual({ id: 1 });
    });

    it('should throw error when request fails', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'Judul kosong' }), { status: 400 })
      );

      await expect(service.postTodo('', 'Desc')).rejects.toThrow('Judul kosong');
    });

    it('should throw fallback error when message is empty', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 400 })
      );

      await expect(service.postTodo('', 'Desc')).rejects.toThrow('Gagal menambahkan todo');
    });
  });

  describe('postTodoCover', () => {
    it('should return message on success', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', message: 'Cover updated' }), { status: 200 })
      );

      const file = new File(['cover'], 'c.jpg', { type: 'image/jpeg' });
      const msg = await service.postTodoCover(1, file);
      expect(msg).toBe('Cover updated');
    });

    it('should throw error when cover upload fails', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'File too large' }), { status: 400 })
      );

      const file = new File(['cover'], '', { type: 'image/jpeg' });
      await expect(service.postTodoCover(1, file)).rejects.toThrow('File too large');
    });

    it('should throw fallback error when message is empty', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 400 })
      );

      const file = new File(['cover'], 'c.jpg', { type: 'image/jpeg' });
      await expect(service.postTodoCover(1, file)).rejects.toThrow('Gagal mengubah cover');
    });
  });

  describe('putTodo', () => {
    it('should return message on success with boolean or numeric is_finished', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockImplementation(() =>
        Promise.resolve(new Response(JSON.stringify({ status: 'success', message: 'Todo updated' }), { status: 200 }))
      );

      const msg = await service.putTodo(1, 'Title', 'Desc', true);
      expect(msg).toBe('Todo updated');

      const msg2 = await service.putTodo(1, 'Title', 'Desc', 0);
      expect(msg2).toBe('Todo updated');
    });

    it('should throw error when update fails', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'Update failed' }), { status: 400 })
      );

      await expect(service.putTodo(1, 'T', 'D', false)).rejects.toThrow('Update failed');
    });

    it('should throw fallback error when message is empty', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 400 })
      );

      await expect(service.putTodo(1, 'T', 'D', false)).rejects.toThrow('Gagal mengubah todo');
    });
  });

  describe('getTodos', () => {
    it('should return todos with and without filter', async () => {
      const fetchSpy = vi.spyOn(ApiHelper, 'fetchData').mockImplementation(() =>
        Promise.resolve(new Response(JSON.stringify({ status: 'success', data: { todos: [mockTodo] } }), { status: 200 }))
      );

      const res = await service.getTodos('');
      expect(res).toEqual([mockTodo]);

      await service.getTodos('1');
      expect(fetchSpy).toHaveBeenCalledWith('https://open-api.delcom.org/api/v1/todos/?is_finished=1', {
        method: 'GET',
      });
    });

    it('should return empty array if data.todos is missing', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', data: {} }), { status: 200 })
      );

      const res = await service.getTodos();
      expect(res).toEqual([]);
    });

    it('should throw error when getTodos fails', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'Server error' }), { status: 500 })
      );

      await expect(service.getTodos()).rejects.toThrow('Server error');
    });

    it('should throw fallback error when message is empty', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 500 })
      );

      await expect(service.getTodos()).rejects.toThrow('Gagal mengambil data todo');
    });
  });

  describe('getTodoById', () => {
    it('should return todo on success', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', data: { todo: mockTodo } }), { status: 200 })
      );

      const res = await service.getTodoById(1);
      expect(res).toEqual(mockTodo);
    });

    it('should throw error when not found', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'Not found' }), { status: 404 })
      );

      await expect(service.getTodoById(99)).rejects.toThrow('Not found');
    });

    it('should throw fallback error when message is empty', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 404 })
      );

      await expect(service.getTodoById(99)).rejects.toThrow('Gagal mengambil detail todo');
    });
  });

  describe('deleteTodo', () => {
    it('should return message on delete success', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', message: 'Deleted' }), { status: 200 })
      );

      const msg = await service.deleteTodo(1);
      expect(msg).toBe('Deleted');
    });

    it('should throw error when delete fails', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'Cannot delete' }), { status: 400 })
      );

      await expect(service.deleteTodo(1)).rejects.toThrow('Cannot delete');
    });

    it('should throw fallback error when message is empty', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 400 })
      );

      await expect(service.deleteTodo(1)).rejects.toThrow('Gagal menghapus todo');
    });
  });

  describe('asyncSetTodos & asyncSetTodo', () => {
    it('should set todos on success and empty array on failure', async () => {
      vi.spyOn(service, 'getTodos').mockResolvedValue([mockTodo]);
      await service.asyncSetTodos();
      expect(service.todos()).toEqual([mockTodo]);

      vi.spyOn(service, 'getTodos').mockRejectedValue(new Error('fail'));
      await service.asyncSetTodos();
      expect(service.todos()).toEqual([]);
    });

    it('should set todo on success and null on failure', async () => {
      vi.spyOn(service, 'getTodoById').mockResolvedValue(mockTodo);
      await service.asyncSetTodo(1);
      expect(service.todo()).toEqual(mockTodo);
      expect(service.isTodo()).toBe(true);

      vi.spyOn(service, 'getTodoById').mockRejectedValue(new Error('fail'));
      await service.asyncSetTodo(1);
      expect(service.todo()).toBeNull();
      expect(service.isTodo()).toBe(true);
    });
  });

  describe('asyncSetIsTodoAdd', () => {
    it('should handle add success', async () => {
      vi.spyOn(service, 'postTodo').mockResolvedValue({ id: 1 });
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncSetIsTodoAdd('Title', 'Desc');

      expect(service.isTodoAdded()).toBe(true);
      expect(service.isTodoAdd()).toBe(true);
      expect(successSpy).toHaveBeenCalled();
    });

    it('should handle add failure', async () => {
      vi.spyOn(service, 'postTodo').mockRejectedValue(new Error('Add fail'));
      const errorSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncSetIsTodoAdd('Title', 'Desc');

      expect(service.isTodoAdded()).toBe(false);
      expect(service.isTodoAdd()).toBe(true);
      expect(errorSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Add fail' }));
    });
  });

  describe('asyncSetIsTodoChange', () => {
    it('should handle change success', async () => {
      vi.spyOn(service, 'putTodo').mockResolvedValue('Update ok');
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncSetIsTodoChange(1, 'Title', 'Desc', true);

      expect(service.isTodoChanged()).toBe(true);
      expect(service.isTodoChange()).toBe(true);
      expect(successSpy).toHaveBeenCalled();
    });

    it('should handle change success with fallback message', async () => {
      vi.spyOn(service, 'putTodo').mockResolvedValue('');
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncSetIsTodoChange(1, 'Title', 'Desc', false);

      expect(successSpy).toHaveBeenCalled();
    });

    it('should handle change failure', async () => {
      vi.spyOn(service, 'putTodo').mockRejectedValue(new Error('Update fail'));
      const errorSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncSetIsTodoChange(1, 'Title', 'Desc', true);

      expect(service.isTodoChanged()).toBe(false);
      expect(service.isTodoChange()).toBe(true);
      expect(errorSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Update fail' }));
    });
  });

  describe('asyncSetIsTodoChangeCover', () => {
    it('should handle change cover success', async () => {
      vi.spyOn(service, 'postTodoCover').mockResolvedValue('Cover ok');
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      const file = new File(['c'], 'cover.png');
      await service.asyncSetIsTodoChangeCover(1, file);

      expect(service.isTodoChangedCover()).toBe(true);
      expect(service.isTodoChangeCover()).toBe(true);
      expect(successSpy).toHaveBeenCalled();
    });

    it('should handle change cover success with fallback message', async () => {
      vi.spyOn(service, 'postTodoCover').mockResolvedValue('');
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      const file = new File(['c'], 'cover.png');
      await service.asyncSetIsTodoChangeCover(1, file);

      expect(successSpy).toHaveBeenCalled();
    });

    it('should handle change cover failure', async () => {
      vi.spyOn(service, 'postTodoCover').mockRejectedValue(new Error('Cover fail'));
      const errorSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      const file = new File(['c'], 'cover.png');
      await service.asyncSetIsTodoChangeCover(1, file);

      expect(service.isTodoChangedCover()).toBe(false);
      expect(service.isTodoChangeCover()).toBe(true);
      expect(errorSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Cover fail' }));
    });
  });

  describe('asyncSetIsTodoDelete', () => {
    it('should handle delete success', async () => {
      vi.spyOn(service, 'deleteTodo').mockResolvedValue('Delete ok');
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncSetIsTodoDelete(1);

      expect(service.isTodoDeleted()).toBe(true);
      expect(service.isTodoDelete()).toBe(true);
      expect(successSpy).toHaveBeenCalled();
    });

    it('should handle delete success with fallback message', async () => {
      vi.spyOn(service, 'deleteTodo').mockResolvedValue('');
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncSetIsTodoDelete(1);

      expect(successSpy).toHaveBeenCalled();
    });

    it('should handle delete failure', async () => {
      vi.spyOn(service, 'deleteTodo').mockRejectedValue(new Error('Delete fail'));
      const errorSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncSetIsTodoDelete(1);

      expect(service.isTodoDeleted()).toBe(false);
      expect(service.isTodoDelete()).toBe(true);
      expect(errorSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Delete fail' }));
    });
  });
});
