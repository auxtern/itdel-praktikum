import { Component, OnInit, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet } from '@angular/router';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { SidebarComponent } from '../../components/sidebar/sidebar.component';
import { UsersService } from '../../../users/services/users.service';
import { AuthService } from '../../../auth/services/auth.service';
import ApiHelper from '../../../../helpers/api.helper';

@Component({
  selector: 'app-todo-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, NavbarComponent, SidebarComponent],
  template: `
    @if (!usersService.profile()) {
      <div class="min-h-screen flex items-center justify-center bg-slate-50">
        <div class="flex flex-col items-center gap-3">
          <div class="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
          <p class="text-sm font-medium text-slate-600">Memuat sesi pengguna...</p>
        </div>
      </div>
    } @else {
      <div class="min-h-screen bg-slate-50 text-slate-800">
        <app-navbar
          [profile]="usersService.profile()"
          [isSidebarOpen]="isSidebarOpen"
          (logout)="handleLogout()"
          (toggleSidebar)="isSidebarOpen = !isSidebarOpen"
        ></app-navbar>

        <app-sidebar
          [isSidebarOpen]="isSidebarOpen"
          (closeMobile)="isSidebarOpen = false"
        ></app-sidebar>

        <main class="pt-16 md:pl-64 transition-all">
          <div class="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
            <router-outlet></router-outlet>
          </div>
        </main>
      </div>
    }
  `,
})
export class TodoLayoutComponent implements OnInit {
  isSidebarOpen = false;

  constructor(
    public usersService: UsersService,
    private authService: AuthService,
    private router: Router
  ) {
    effect(() => {
      const isProfile = this.usersService.isProfile();
      if (isProfile) {
        this.usersService.isProfile.set(false);
        if (!this.usersService.profile()) {
          ApiHelper.putAccessToken('');
          this.router.navigate(['/auth/login']);
        }
      }
    });

    effect(() => {
      const isAuthLogout = this.authService.isAuthLogout();
      if (isAuthLogout) {
        this.authService.isAuthLogout.set(false);
        this.router.navigate(['/auth/login']);
      }
    });
  }

  ngOnInit(): void {
    const token = ApiHelper.getAccessToken();
    if (token) {
      this.usersService.asyncSetProfile();
    } else {
      this.router.navigate(['/auth/login']);
    }
  }

  handleLogout(): void {
    this.authService.asyncSetIsAuthLogout();
  }
}
