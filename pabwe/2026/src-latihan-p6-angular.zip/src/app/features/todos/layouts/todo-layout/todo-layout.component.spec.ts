import { describe, it, expect, vi, beforeEach } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { By } from '@angular/platform-browser';
import { TodoLayoutComponent } from './todo-layout.component';
import { UsersService } from '../../../users/services/users.service';
import { AuthService } from '../../../auth/services/auth.service';
import ApiHelper from '../../../../helpers/api.helper';

describe('TodoLayoutComponent', () => {
  let component: TodoLayoutComponent;
  let usersService: UsersService;
  let authService: AuthService;
  let router: Router;

  beforeEach(async () => {
    vi.restoreAllMocks();

    await TestBed.configureTestingModule({
      imports: [TodoLayoutComponent],
      providers: [provideRouter([{ path: 'auth/login', component: class {} }, { path: '**', component: class {} }])],
    }).compileComponents();

    usersService = TestBed.inject(UsersService);
    authService = TestBed.inject(AuthService);
    router = TestBed.inject(Router);

    usersService.isProfile.set(false);
    usersService.profile.set(null);
    authService.isAuthLogout.set(false);

    vi.spyOn(ApiHelper, 'getAccessToken').mockReturnValue('valid-token');
    vi.spyOn(usersService, 'asyncSetProfile').mockImplementation(() => Promise.resolve());

    const fixture = TestBed.createComponent(TodoLayoutComponent);
    component = fixture.componentInstance;
  });

  it('should render loading session when profile is null', () => {
    usersService.profile.set(null);
    const fixture = TestBed.createComponent(TodoLayoutComponent);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.textContent).toContain('Memuat sesi pengguna...');
  });

  it('should render navbar and sidebar when profile is present', () => {
    usersService.profile.set({ id: 1, name: 'Abdullah' } as any);
    const fixture = TestBed.createComponent(TodoLayoutComponent);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('app-navbar')).not.toBeNull();
    expect(el.querySelector('app-sidebar')).not.toBeNull();

    const navbarDebug = fixture.debugElement.query(By.css('app-navbar'));
    navbarDebug?.triggerEventHandler('toggleSidebar', null);
    expect(fixture.componentInstance.isSidebarOpen).toBe(true);

    const handleLogoutSpy = vi.spyOn(fixture.componentInstance, 'handleLogout');
    navbarDebug?.triggerEventHandler('logout', null);
    expect(handleLogoutSpy).toHaveBeenCalled();

    const sidebarDebug = fixture.debugElement.query(By.css('app-sidebar'));
    sidebarDebug?.triggerEventHandler('closeMobile', null);
    expect(fixture.componentInstance.isSidebarOpen).toBe(false);
  });

  it('should call asyncSetProfile on ngOnInit if token exists', () => {
    vi.spyOn(ApiHelper, 'getAccessToken').mockReturnValue('valid-token');
    const spy = vi.spyOn(usersService, 'asyncSetProfile').mockImplementation(() => Promise.resolve());

    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  it('should redirect to /auth/login on ngOnInit if token is missing', () => {
    vi.spyOn(ApiHelper, 'getAccessToken').mockReturnValue(null);
    const navSpy = vi.spyOn(router, 'navigate').mockImplementation(() => Promise.resolve(true));

    component.ngOnInit();
    expect(navSpy).toHaveBeenCalledWith(['/auth/login']);
  });

  it('should handle logout by calling authService.asyncSetIsAuthLogout', () => {
    const logoutSpy = vi.spyOn(authService, 'asyncSetIsAuthLogout').mockImplementation(() => Promise.resolve());
    component.handleLogout();
    expect(logoutSpy).toHaveBeenCalled();
  });

  it('should redirect to /auth/login when isProfile is triggered and profile is null, but not when profile exists', () => {
    const navSpy = vi.spyOn(router, 'navigate').mockImplementation(() => Promise.resolve(true));
    const putTokenSpy = vi.spyOn(ApiHelper, 'putAccessToken').mockImplementation(() => {});

    // isProfile false
    usersService.isProfile.set(false);
    TestBed.flushEffects();

    // profile exists
    usersService.profile.set({ id: 1 } as any);
    usersService.isProfile.set(true);
    TestBed.flushEffects();
    expect(navSpy).not.toHaveBeenCalled();

    // profile is null
    usersService.profile.set(null);
    usersService.isProfile.set(true);
    TestBed.flushEffects();

    expect(putTokenSpy).toHaveBeenCalledWith('');
    expect(navSpy).toHaveBeenCalledWith(['/auth/login']);
  });

  it('should redirect to /auth/login when isAuthLogout is true, and do nothing when false', () => {
    const navSpy = vi.spyOn(router, 'navigate').mockImplementation(() => Promise.resolve(true));

    authService.isAuthLogout.set(false);
    TestBed.flushEffects();
    expect(navSpy).not.toHaveBeenCalled();

    authService.isAuthLogout.set(true);
    TestBed.flushEffects();

    expect(navSpy).toHaveBeenCalledWith(['/auth/login']);
  });
});
