import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <div>
      @if (isSidebarOpen) {
        <div
          data-testid="sidebar-backdrop"
          (click)="closeMobile.emit()"
          (keydown.escape)="closeMobile.emit()"
          role="button"
          tabindex="0"
          aria-label="Tutup Menu"
          class="fixed inset-0 z-30 bg-slate-900/40 backdrop-blur-xs md:hidden"
        ></div>
      }

      <aside
        class="fixed top-16 bottom-0 left-0 z-30 w-64 bg-white border-r border-slate-200/80 p-4 transition-transform duration-200 ease-in-out md:translate-x-0"
        [class.translate-x-0]="isSidebarOpen"
        [class.-translate-x-full]="!isSidebarOpen"
      >
        <div class="flex flex-col h-full justify-between">
          <div class="space-y-6">
            <div>
              <p class="px-3 text-xs font-bold uppercase tracking-wider text-slate-400">
                Menu Utama
              </p>
              <nav class="mt-3 space-y-1">
                <a
                  routerLink="/"
                  [routerLinkActiveOptions]="{ exact: true }"
                  routerLinkActive="bg-indigo-600 text-white shadow-md shadow-indigo-600/25 font-semibold"
                  #rlaHome="routerLinkActive"
                  (click)="closeMobile.emit()"
                  class="group flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                >
                  <div class="flex items-center gap-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" [class.text-white]="rlaHome.isActive" [class.text-slate-400]="!rlaHome.isActive"><rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/></svg>
                    <span>Semua Todo</span>
                  </div>
                  @if (rlaHome.isActive) {
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                  }
                </a>

                <a
                  routerLink="/users"
                  routerLinkActive="bg-indigo-600 text-white shadow-md shadow-indigo-600/25 font-semibold"
                  #rlaUsers="routerLinkActive"
                  (click)="closeMobile.emit()"
                  class="group flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                >
                  <div class="flex items-center gap-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" [class.text-white]="rlaUsers.isActive" [class.text-slate-400]="!rlaUsers.isActive"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    <span>Semua Pengguna</span>
                  </div>
                  @if (rlaUsers.isActive) {
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                  }
                </a>

                <a
                  routerLink="/profile"
                  routerLinkActive="bg-indigo-600 text-white shadow-md shadow-indigo-600/25 font-semibold"
                  #rlaProfile="routerLinkActive"
                  (click)="closeMobile.emit()"
                  class="group flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                >
                  <div class="flex items-center gap-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" [class.text-white]="rlaProfile.isActive" [class.text-slate-400]="!rlaProfile.isActive"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="10" r="3"/><path d="M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662"/></svg>
                    <span>Profil Saya</span>
                  </div>
                  @if (rlaProfile.isActive) {
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                  }
                </a>
              </nav>
            </div>
          </div>

          <!-- Footer note in sidebar -->
          <div class="p-3 rounded-2xl bg-gradient-to-br from-indigo-50 to-slate-50 border border-indigo-100/60">
            <p class="text-xs font-semibold text-indigo-900">
              Praktikum 6 PABWE (Angular)
            </p>
          </div>
        </div>
      </aside>
    </div>
  `,
})
export class SidebarComponent {
  @Input() isSidebarOpen: boolean = false;
  @Output() closeMobile = new EventEmitter<void>();
}
