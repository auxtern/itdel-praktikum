import { describe, it, expect, vi, beforeEach } from 'vitest';
import { MarkdownEditorComponent } from './markdown-editor.component';

let mockChangeCallback: (() => void) | undefined;

vi.mock('@toast-ui/editor', () => {
  return {
    default: class MockEditor {
      options: any;
      constructor(options: any) {
        this.options = options;
        mockChangeCallback = options.events?.change;
      }
      getMarkdown = vi.fn().mockReturnValue('Updated content');
      setMarkdown = vi.fn();
      destroy = vi.fn();
    },
  };
});

import { TestBed } from '@angular/core/testing';

describe('MarkdownEditorComponent', () => {
  let component: MarkdownEditorComponent;
  let fixture: any;

  beforeEach(async () => {
    vi.clearAllMocks();
    mockChangeCallback = undefined;

    await TestBed.configureTestingModule({
      imports: [MarkdownEditorComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(MarkdownEditorComponent);
    component = fixture.componentInstance;
  });

  it('should initialize editor and handle change event and template textarea input', () => {
    const emitSpy = vi.spyOn(component.valueChange, 'emit');
    component.value = 'Initial';
    fixture.detectChanges();

    expect((component as any).editorInstance).not.toBeNull();

    // Trigger change callback from editor
    if (mockChangeCallback) {
      mockChangeCallback();
      expect(component.value).toBe('Updated content');
      expect(emitSpy).toHaveBeenCalledWith('Updated content');
    }

    // Trigger template textarea input
    const textarea = fixture.nativeElement.querySelector('textarea') as HTMLTextAreaElement;
    textarea.value = 'From template';
    textarea.dispatchEvent(new Event('input'));
    expect(component.value).toBe('From template');
    expect(emitSpy).toHaveBeenCalledWith('From template');
  });

  it('should handle onTextareaInput event with and without editorInstance', () => {
    fixture.detectChanges();
    const emitSpy = vi.spyOn(component.valueChange, 'emit');

    const textarea = document.createElement('textarea');
    textarea.value = 'Textarea input';
    component.onTextareaInput({ target: textarea } as any);

    expect(component.value).toBe('Textarea input');
    expect(emitSpy).toHaveBeenCalledWith('Textarea input');
    expect((component as any).editorInstance.setMarkdown).toHaveBeenCalledWith('Textarea input');

    // Test when editorInstance is null
    (component as any).editorInstance = null;
    component.onTextareaInput({ target: textarea } as any);
  });

  it('should destroy editor on ngOnDestroy', () => {
    fixture.detectChanges();
    const instance = (component as any).editorInstance;

    component.ngOnDestroy();
    expect(instance.destroy).toHaveBeenCalled();
    expect((component as any).editorInstance).toBeNull();
  });

  it('should safely handle ngOnDestroy when editorInstance is null', () => {
    expect(() => component.ngOnDestroy()).not.toThrow();
  });
});
