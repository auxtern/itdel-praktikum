import {
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnDestroy,
  AfterViewInit,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import Viewer from '@toast-ui/editor/dist/toastui-editor-viewer';

@Component({
  selector: 'app-markdown-viewer',
  standalone: true,
  template: `
    <div #viewerContainer class="toastui-editor-viewer-wrapper" data-testid="markdown-viewer"></div>
  `,
  styles: [`
    :host ::ng-deep .toastui-editor-viewer-wrapper .toastui-editor-contents {
      font-family: inherit;
      font-size: 0.95rem;
      color: #475569;
    }
  `],
})
export class MarkdownViewerComponent implements AfterViewInit, OnChanges, OnDestroy {
  @Input() content: string = '';

  @ViewChild('viewerContainer') viewerContainer!: ElementRef<HTMLDivElement>;

  private viewerInstance: any = null;

  ngAfterViewInit(): void {
    this.viewerInstance = new Viewer({
      el: this.viewerContainer.nativeElement,
      initialValue: this.content || '',
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['content'] && this.viewerInstance) {
      this.viewerInstance.setMarkdown(this.content || '');
    }
  }

  ngOnDestroy(): void {
    if (this.viewerInstance) {
      this.viewerInstance.destroy();
      this.viewerInstance = null;
    }
  }
}
