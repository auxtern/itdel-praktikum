import { describe, it, expect, vi, beforeEach } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { NavbarComponent } from './navbar.component';

describe('NavbarComponent', () => {
  let component: NavbarComponent;
  let fixture: any;
  let router: Router;

  beforeEach(async () => {
    vi.restoreAllMocks();

    await TestBed.configureTestingModule({
      imports: [NavbarComponent],
      providers: [
        provideRouter([
          { path: 'profile', component: class {} },
          { path: '**', component: class {} },
        ]),
      ],
    }).compileComponents();

    router = TestBed.inject(Router);
    fixture = TestBed.createComponent(NavbarComponent);
    component = fixture.componentInstance;
  });

  it('should render brand and toggle sidebar button', () => {
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.textContent).toContain('Delcom Todo');

    const toggleSpy = vi.spyOn(component.toggleSidebar, 'emit');
    const toggleBtn = el.querySelector('[data-testid="toggle-sidebar-btn"]') as HTMLElement;
    toggleBtn.click();
    expect(toggleSpy).toHaveBeenCalled();

    component.isSidebarOpen = true;
    fixture.detectChanges();
    expect(el.querySelector('[data-testid="toggle-sidebar-btn"] svg')).toBeTruthy();
  });

  it('should render profile photo and details when available', () => {
    component.profile = {
      id: 1,
      name: 'Abdullah',
      email: 'abdul@delcom.org',
      photo: 'https://example.com/p.jpg',
    };
    fixture.detectChanges();

    const el = fixture.nativeElement as HTMLElement;
    const img = el.querySelector('img');
    expect(img).not.toBeNull();
    expect(img?.src).toContain('https://example.com/p.jpg');
    expect(el.textContent).toContain('Abdullah');
    expect(el.textContent).toContain('abdul@delcom.org');

    // Toggle dropdown open
    const dropdownBtn = el.querySelector('[data-testid="profile-dropdown-button"]') as HTMLElement;
    dropdownBtn.click();
    fixture.detectChanges();
    expect(component.dropdownOpen).toBe(true);

    const profileLink = el.querySelector('[data-testid="dropdown-profile-link"]') as HTMLElement;
    expect(profileLink).toBeTruthy();
    profileLink.click();
    expect(component.dropdownOpen).toBe(false);

    dropdownBtn.click();
    fixture.detectChanges();
    const logoutBtn = el.querySelector('[data-testid="dropdown-logout-button"]') as HTMLElement;
    expect(logoutBtn).toBeTruthy();
    logoutBtn.click();
    expect(component.dropdownOpen).toBe(false);
  });

  it('should render initial fallback when photo is null and handle empty name', () => {
    component.profile = {
      id: 2,
      name: '',
      email: '',
      photo: null,
    };
    fixture.detectChanges();

    const el = fixture.nativeElement as HTMLElement;
    expect(el.textContent).toContain('U');
    expect(el.textContent).toContain('Pengguna');
  });

  it('should render initial from name when photo is null and name is present', () => {
    const f = TestBed.createComponent(NavbarComponent);
    f.componentInstance.profile = {
      id: 3,
      name: 'Bob',
      email: 'bob@example.com',
      photo: null,
    };
    f.detectChanges();
    expect(f.nativeElement.textContent).toContain('B');
    expect(f.nativeElement.textContent).toContain('Bob');
  });

  it('should toggle dropdown, navigate to profile, and emit logout', () => {
    const navSpy = vi.spyOn(router, 'navigate').mockImplementation(() => Promise.resolve(true));
    const logoutSpy = vi.spyOn(component.logout, 'emit');

    component.dropdownOpen = true;
    component.handleProfileClick();
    expect(component.dropdownOpen).toBe(false);
    expect(navSpy).toHaveBeenCalledWith(['/profile']);

    component.dropdownOpen = true;
    component.handleLogoutClick();
    expect(component.dropdownOpen).toBe(false);
    expect(logoutSpy).toHaveBeenCalled();
  });

  it('should render fallback when profile is completely null', () => {
    component.profile = null;
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.textContent).toContain('Pengguna');
  });

  it('should close dropdown on document click outside and keep open on inside click', () => {
    component.dropdownOpen = true;
    const outsideEl = document.createElement('div');
    component.handleClickOutside({ target: outsideEl } as any);
    expect(component.dropdownOpen).toBe(false);

    // click inside
    component.dropdownOpen = true;
    component.handleClickOutside({ target: fixture.nativeElement } as any);
    expect(component.dropdownOpen).toBe(true);

    // via document mousedown
    document.dispatchEvent(new MouseEvent('mousedown'));
    expect(component.dropdownOpen).toBe(false);
  });
});
