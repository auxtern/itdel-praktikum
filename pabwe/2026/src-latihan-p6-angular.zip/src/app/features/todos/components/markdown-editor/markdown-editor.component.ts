import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  AfterViewInit,
  Output,
  ViewChild,
} from '@angular/core';
import Editor from '@toast-ui/editor';

@Component({
  selector: 'app-markdown-editor',
  standalone: true,
  template: `
    <div class="toastui-editor-wrapper">
      <textarea
        [attr.data-testid]="textareaTestId"
        [value]="value"
        (input)="onTextareaInput($event)"
        class="hidden"
        tabindex="-1"
        aria-hidden="true"
      ></textarea>
      <div #editorContainer data-testid="markdown-editor-container"></div>
    </div>
  `,
  styles: [`
    .toastui-editor-wrapper {
      display: flex;
      flex-direction: column;
      height: 100%;
      width: 100%;
    }
    .toastui-editor-wrapper > div[data-testid="markdown-editor-container"] {
      height: 100%;
      width: 100%;
      display: flex;
      flex-direction: column;
    }
    :host ::ng-deep .toastui-editor-defaultUI {
      display: flex;
      flex-direction: column;
      height: 100%;
      border: 1px solid #e2e8f0;
      border-radius: 0.75rem;
      overflow: hidden;
      font-family: inherit;
    }
    :host ::ng-deep .toastui-editor-main {
      flex: 1;
      min-height: 0;
    }
    :host ::ng-deep .toastui-editor-toolbar {
      background-color: #f8fafc;
      border-bottom: 1px solid #f1f5f9;
    }
    :host ::ng-deep .toastui-editor-contents {
      font-family: inherit;
      font-size: 0.875rem;
    }
  `],
})
export class MarkdownEditorComponent implements AfterViewInit, OnDestroy {
  @Input() value: string = '';
  @Input() placeholder: string = 'Tulis deskripsi dengan format Markdown...';
  @Input() height: string = '240px';
  @Input() textareaTestId: string = 'markdown-editor-textarea';

  @Output() valueChange = new EventEmitter<string>();

  @ViewChild('editorContainer') editorContainer!: ElementRef<HTMLDivElement>;

  private editorInstance: any = null;

  ngAfterViewInit(): void {
    this.editorInstance = new Editor({
      el: this.editorContainer.nativeElement,
      height: this.height,
      initialEditType: 'markdown',
      previewStyle: 'tab',
      initialValue: this.value || '',
      placeholder: this.placeholder,
      usageStatistics: false,
      hideModeSwitch: false,
      events: {
        change: () => {
          const markdown = this.editorInstance.getMarkdown();
          this.value = markdown;
          this.valueChange.emit(markdown);
        },
      },
    });
  }

  onTextareaInput(event: Event): void {
    const val = (event.target as HTMLTextAreaElement).value;
    this.value = val;
    this.valueChange.emit(val);
    if (this.editorInstance) {
      this.editorInstance.setMarkdown(val);
    }
  }

  ngOnDestroy(): void {
    if (this.editorInstance) {
      this.editorInstance.destroy();
      this.editorInstance = null;
    }
  }
}
