import { describe, it, expect, vi, beforeEach } from 'vitest';
import { SimpleChange } from '@angular/core';
import { MarkdownViewerComponent } from './markdown-viewer.component';

vi.mock('@toast-ui/editor/dist/toastui-editor-viewer', () => {
  return {
    default: class MockViewer {
      setMarkdown = vi.fn();
      destroy = vi.fn();
    },
  };
});

describe('MarkdownViewerComponent', () => {
  let component: MarkdownViewerComponent;

  beforeEach(() => {
    vi.clearAllMocks();
    component = new MarkdownViewerComponent();
    component.viewerContainer = {
      nativeElement: document.createElement('div'),
    };
  });

  it('should initialize Viewer on ngAfterViewInit', () => {
    component.content = '# Heading';
    component.ngAfterViewInit();
    expect((component as any).viewerInstance).not.toBeNull();
  });

  it('should update content on ngOnChanges when viewerInstance exists', () => {
    component.content = '# Initial';
    component.ngAfterViewInit();

    component.content = '# Updated';
    component.ngOnChanges({
      content: new SimpleChange('# Initial', '# Updated', false),
    });
    expect((component as any).viewerInstance.setMarkdown).toHaveBeenCalledWith('# Updated');

    component.content = '';
    component.ngOnChanges({
      content: new SimpleChange('# Updated', '', false),
    });
    expect((component as any).viewerInstance.setMarkdown).toHaveBeenCalledWith('');
  });

  it('should destroy viewer on ngOnDestroy', () => {
    component.ngAfterViewInit();
    const instance = (component as any).viewerInstance;

    component.ngOnDestroy();
    expect(instance.destroy).toHaveBeenCalled();
    expect((component as any).viewerInstance).toBeNull();
  });

  it('should handle ngOnDestroy and ngOnChanges when viewerInstance is null', () => {
    expect(() => component.ngOnDestroy()).not.toThrow();
    expect(() =>
      component.ngOnChanges({
        content: new SimpleChange('', 'test', true),
      })
    ).not.toThrow();
  });
});
