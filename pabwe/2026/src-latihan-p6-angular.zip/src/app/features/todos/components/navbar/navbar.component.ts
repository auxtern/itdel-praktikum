import {
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  Output,
} from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import type { User } from '../../../users/models/user.model';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <header class="fixed top-0 left-0 right-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200/80 shadow-xs transition-all">
      <div class="w-full flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
        <div class="flex items-center gap-3">
          <button
            type="button"
            data-testid="toggle-sidebar-btn"
            (click)="toggleSidebar.emit()"
            class="md:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors"
            aria-label="Toggle Navigation"
          >
            @if (isSidebarOpen) {
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
            } @else {
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
            }
          </button>

          <a routerLink="/" class="flex items-center gap-3 group">
            <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-cyan-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform">
              <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="m9 12 2 2 4-4"/></svg>
            </div>
            <div>
              <span class="text-lg font-bold bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-800 bg-clip-text text-transparent">
                Delcom Todo
              </span>
            </div>
          </a>
        </div>

        <!-- Profile User Dropdown -->
        <div class="relative">
          <button
            type="button"
            data-testid="profile-dropdown-button"
            (click)="dropdownOpen = !dropdownOpen"
            class="flex items-center gap-3 p-1.5 pr-3 rounded-full border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-all focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
          >
            @if (profile?.photo) {
              <img
                [src]="profile?.photo"
                [alt]="profile?.name"
                class="w-8 h-8 rounded-full object-cover border border-slate-200"
              />
            } @else {
              <div class="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center font-bold text-xs">
                {{ profile?.name ? profile?.name?.charAt(0)?.toUpperCase() : 'U' }}
              </div>
            }

            <div class="hidden sm:flex flex-col text-left">
              <span class="text-sm font-semibold text-slate-800 leading-tight">
                {{ profile?.name || 'Pengguna' }}
              </span>
              <span class="text-xs text-slate-500 leading-tight">
                {{ profile?.email || '' }}
              </span>
            </div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
              class="text-slate-400 transition-transform duration-200"
              [class.rotate-180]="dropdownOpen"
            ><path d="m6 9 6 6 6-6"/></svg>
          </button>

          @if (dropdownOpen) {
            <div
              data-testid="profile-dropdown-menu"
              class="absolute right-0 mt-2 w-56 rounded-2xl bg-white p-2 shadow-xl ring-1 ring-slate-900/5 divide-y divide-slate-100 z-50 animate-in fade-in zoom-in-95 duration-150"
            >
              <div class="px-3 py-2 sm:hidden">
                <p class="text-sm font-semibold text-slate-800">{{ profile?.name }}</p>
                <p class="text-xs text-slate-500 truncate">{{ profile?.email }}</p>
              </div>

              <div class="py-1">
                <button
                  type="button"
                  data-testid="dropdown-profile-link"
                  (click)="handleProfileClick()"
                  class="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-slate-700 rounded-xl hover:bg-slate-100 transition-colors text-left"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-slate-500"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                  Profil Saya
                </button>
              </div>

              <div class="pt-1">
                <button
                  type="button"
                  data-testid="dropdown-logout-button"
                  (click)="handleLogoutClick()"
                  class="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-red-600 rounded-xl hover:bg-red-50 transition-colors text-left"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-red-500"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>
                  Keluar
                </button>
              </div>
            </div>
          }
        </div>
      </div>
    </header>
  `,
})
export class NavbarComponent {
  @Input() profile: User | null = null;
  @Input() isSidebarOpen: boolean = false;

  @Output() toggleSidebar = new EventEmitter<void>();
  @Output() logout = new EventEmitter<void>();

  dropdownOpen: boolean = false;

  constructor(
    private router: Router,
    private elementRef: ElementRef
  ) {}

  @HostListener('document:mousedown', ['$event'])
  handleClickOutside(event: MouseEvent): void {
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.dropdownOpen = false;
    }
  }

  handleProfileClick(): void {
    this.dropdownOpen = false;
    this.router.navigate(['/profile']);
  }

  handleLogoutClick(): void {
    this.dropdownOpen = false;
    this.logout.emit();
  }
}
