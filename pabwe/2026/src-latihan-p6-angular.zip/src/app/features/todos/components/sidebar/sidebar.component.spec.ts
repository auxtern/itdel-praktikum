import { describe, it, expect, vi } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { SidebarComponent } from './sidebar.component';

describe('SidebarComponent', () => {
  it('should render navigation links and emit closeMobile on link click', async () => {
    await TestBed.configureTestingModule({
      imports: [SidebarComponent],
      providers: [
        provideRouter([
          { path: '', pathMatch: 'full', component: class {} },
          { path: 'users', component: class {} },
          { path: 'profile', component: class {} },
        ]),
      ],
    }).compileComponents();

    const router = TestBed.inject(Router);
    const fixture = TestBed.createComponent(SidebarComponent);
    const component = fixture.componentInstance;
    component.isSidebarOpen = true;

    await router.navigateByUrl('/');
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    const emitSpy = vi.spyOn(component.closeMobile, 'emit');

    const el = fixture.nativeElement as HTMLElement;
    expect(el.textContent).toContain('Semua Todo');
    expect(el.textContent).toContain('Semua Pengguna');
    expect(el.textContent).toContain('Profil Saya');

    // Click backdrop and press escape
    const backdrop = el.querySelector('[data-testid="sidebar-backdrop"]') as HTMLElement;
    expect(backdrop).not.toBeNull();
    backdrop.click();
    backdrop.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    expect(emitSpy).toHaveBeenCalledTimes(2);

    // Click all links
    const links = el.querySelectorAll('aside a');
    expect(links.length).toBe(3);
    (links[0] as HTMLElement).click();
    (links[1] as HTMLElement).click();
    (links[2] as HTMLElement).click();
    expect(emitSpy).toHaveBeenCalledTimes(5);

    // Test active state for other routes
    await router.navigateByUrl('/users');
    fixture.detectChanges();

    await router.navigateByUrl('/profile');
    fixture.detectChanges();
  });

  it('should not render backdrop when isSidebarOpen is false', async () => {
    await TestBed.configureTestingModule({
      imports: [SidebarComponent],
      providers: [provideRouter([])],
    }).compileComponents();

    const fixture = TestBed.createComponent(SidebarComponent);
    const component = fixture.componentInstance;
    component.isSidebarOpen = false;
    fixture.detectChanges();

    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('[data-testid="sidebar-backdrop"]')).toBeNull();
  });
});
