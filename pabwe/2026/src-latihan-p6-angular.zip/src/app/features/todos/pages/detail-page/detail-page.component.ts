import { Component, OnInit, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { TodosService } from '../../services/todos.service';
import { UsersService } from '../../../users/services/users.service';
import { formatDate, showConfirmDialog } from '../../../../helpers/tools.helper';
import { MarkdownViewerComponent } from '../../components/markdown-viewer/markdown-viewer.component';
import { ChangeModalComponent } from '../../modals/change-modal/change-modal.component';
import { ChangeCoverModalComponent } from '../../modals/change-cover-modal/change-cover-modal.component';

@Component({
  selector: 'app-detail-page',
  standalone: true,
  imports: [
    CommonModule,
    MarkdownViewerComponent,
    ChangeModalComponent,
    ChangeCoverModalComponent,
  ],
  template: `
    @if (!usersService.profile() || !todosService.todo()) {
      <div class="flex flex-col items-center justify-center py-20">
        <div class="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    } @else {
      @let todo = todosService.todo()!;
      <div class="space-y-6 max-w-4xl mx-auto animate-in fade-in duration-300">
        <!-- Back button & Action buttons -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <a
            href="/"
            data-testid="back-to-todos-link"
            (click)="$event.preventDefault(); goBack()"
            class="inline-flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-indigo-600 transition-colors cursor-pointer"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>
            Kembali ke Todo
          </a>

          <div class="flex items-center gap-2">
            <button
              type="button"
              data-testid="edit-cover-btn"
              (click)="showCoverModal = true"
              class="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl text-sky-700 bg-sky-50 hover:bg-sky-100 border border-sky-200/60 transition-colors cursor-pointer"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7"/><line x1="16" x2="22" y1="5" y2="5"/><line x1="19" x2="19" y1="2" y2="8"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
              Ubah Cover
            </button>
            <button
              type="button"
              data-testid="edit-detail-todo-btn"
              (click)="showEditModal = true"
              class="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200/60 transition-colors cursor-pointer"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/><path d="m15 5 3 3"/></svg>
              Ubah Data
            </button>
            <button
              type="button"
              data-testid="delete-detail-todo-btn"
              (click)="handleDelete()"
              class="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl text-red-700 bg-red-50 hover:bg-red-100 border border-red-200/60 transition-colors cursor-pointer"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
              Hapus
            </button>
          </div>
        </div>

        <!-- Main Detail Card -->
        <div class="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
          @if (todo.cover) {
            <div class="relative w-full h-64 sm:h-80 bg-slate-900 overflow-hidden">
              <img
                [src]="todo.cover"
                [alt]="todo.title"
                class="w-full h-full object-cover"
              />
              <div class="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent"></div>
            </div>
          }

          <div class="p-6 sm:p-8 space-y-6">
            <div class="space-y-3">
              <div class="flex items-center gap-3">
                <span class="font-mono text-xs font-bold text-slate-400">
                  #{{ todo.id }}
                </span>
                @if (todo.is_finished) {
                  <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                    Selesai
                  </span>
                } @else {
                  <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    Sedang Proses
                  </span>
                }
              </div>

              <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                {{ todo.title }}
              </h1>

              <div class="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400">
                <div class="flex items-center gap-1.5">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="shrink-0"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg>
                  <span>Dibuat: <strong class="text-slate-500">{{ formatDate(todo.created_at) }}</strong></span>
                </div>
                <div class="flex items-center gap-1.5">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="shrink-0"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg>
                  <span>Diperbarui: <strong class="text-slate-500">{{ formatDate(todo.updated_at) }}</strong></span>
                </div>
              </div>
            </div>

            <div
              data-testid="todo-detail-description"
              class="prose max-w-none text-slate-600 bg-slate-50/60 p-6 rounded-2xl border border-slate-100 leading-relaxed"
            >
              @if (todo.description) {
                <app-markdown-viewer [content]="todo.description"></app-markdown-viewer>
              } @else {
                <p class="italic text-slate-400">Tidak ada deskripsi rinci untuk todo ini.</p>
              }
            </div>
          </div>
        </div>

        <!-- Cover Modal -->
        <app-change-cover-modal
          [show]="showCoverModal"
          [todo]="todo"
          (close)="showCoverModal = false"
        ></app-change-cover-modal>

        <!-- Edit Modal -->
        <app-change-modal
          [show]="showEditModal"
          [todoId]="todo.id"
          (close)="showEditModal = false"
        ></app-change-modal>
      </div>
    }
  `,
})
export class DetailPageComponent implements OnInit {
  showCoverModal = false;
  showEditModal = false;
  todoId: string | number = '';
  formatDate = formatDate;

  constructor(
    public todosService: TodosService,
    public usersService: UsersService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    effect(() => {
      const isTodo = this.todosService.isTodo();
      if (isTodo) {
        this.todosService.isTodo.set(false);
        if (!this.todosService.todo()) {
          this.router.navigate(['/']);
        }
      }
    });

    effect(() => {
      const isTodoDeleted = this.todosService.isTodoDeleted();
      if (isTodoDeleted) {
        this.todosService.isTodoDeleted.set(false);
        this.router.navigate(['/']);
      }
    });
  }

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      this.todoId = params['todoId'];
      if (this.todoId) {
        this.todosService.asyncSetTodo(this.todoId);
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/']);
  }

  async handleDelete(): Promise<void> {
    const result = await showConfirmDialog('Apakah Anda yakin ingin menghapus todo ini?');
    const currentTodo = this.todosService.todo();
    if (result.isConfirmed && currentTodo) {
      this.todosService.asyncSetIsTodoDelete(currentTodo.id);
    }
  }
}
