import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { provideRouter, Router } from '@angular/router';
import { HomePageComponent } from './home-page.component';
import { TodosService } from '../../services/todos.service';
import { UsersService } from '../../../users/services/users.service';
import Swal from 'sweetalert2';

describe('HomePageComponent', () => {
  let component: HomePageComponent;
  let fixture: ComponentFixture<HomePageComponent>;
  let todosService: TodosService;
  let usersService: UsersService;
  let router: Router;

  beforeEach(async () => {
    localStorage.clear();
    await TestBed.configureTestingModule({
      imports: [HomePageComponent],
      providers: [provideRouter([])],
    }).compileComponents();

    todosService = TestBed.inject(TodosService);
    usersService = TestBed.inject(UsersService);
    router = TestBed.inject(Router);

    vi.spyOn(router, 'navigate').mockResolvedValue(true as any);
    vi.spyOn(todosService, 'asyncSetTodos').mockResolvedValue(undefined as any);
    vi.spyOn(todosService, 'asyncSetIsTodoDelete').mockResolvedValue(undefined as any);

    usersService.profile.set({
      id: 1,
      name: 'John Doe',
      email: 'john@example.com',
    } as any);

    fixture = TestBed.createComponent(HomePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should initialize and load todos on init', () => {
    expect(component).toBeTruthy();
    expect(todosService.asyncSetTodos).toHaveBeenCalledWith('');
  });

  it('should handle setFilter and load todos', () => {
    component.setFilter('1');
    expect(component.filter).toBe('1');
    expect(todosService.asyncSetTodos).toHaveBeenCalledWith('1');

    component.setFilter('0');
    expect(component.filter).toBe('0');
    expect(todosService.asyncSetTodos).toHaveBeenCalledWith('0');
  });

  it('should calculate stats properly', () => {
    todosService.todos.set([
      { id: 1, title: 'Todo 1', is_finished: true } as any,
      { id: 2, title: 'Todo 2', is_finished: false } as any,
      { id: 3, title: 'Todo 3', is_finished: false } as any,
    ]);

    expect(component.totalCount).toBe(3);
    expect(component.finishedCount).toBe(1);
    expect(component.pendingCount).toBe(2);
  });

  it('should return empty stats when todos list is null', () => {
    todosService.todos.set(null as any);
    expect(component.totalCount).toBe(0);
    expect(component.finishedCount).toBe(0);
    expect(component.pendingCount).toBe(0);
  });

  it('should filter todos by search query matching title or description', () => {
    todosService.todos.set([
      { id: 1, title: 'Learn Angular', description: 'Deep dive' } as any,
      { id: 2, title: 'Exercise', description: 'Morning run' } as any,
      { id: 3, title: null, description: null } as any,
    ]);

    // Empty search query
    component.searchQuery = '   ';
    expect(component.filteredTodos.length).toBe(3);

    // Matching title
    component.searchQuery = 'angular';
    expect(component.filteredTodos.length).toBe(1);
    expect(component.filteredTodos[0].id).toBe(1);

    // Matching description
    component.searchQuery = 'run';
    expect(component.filteredTodos.length).toBe(1);
    expect(component.filteredTodos[0].id).toBe(2);

    // No match
    component.searchQuery = 'nonexistent';
    expect(component.filteredTodos.length).toBe(0);

    // When todos is null
    todosService.todos.set(null as any);
    component.searchQuery = 'test';
    expect(component.filteredTodos).toEqual([]);
  });

  it('should render nothing when profile is null', () => {
    usersService.profile.set(null);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('[data-testid="add-todo-btn"]')).toBeNull();
  });

  it('should update searchQuery via ngModelChange in template', () => {
    fixture.detectChanges();
    const searchDe = fixture.debugElement.query(By.css('[data-testid="search-todo-input"]'));
    searchDe?.triggerEventHandler('ngModelChange', 'Searching query');
    expect(component.searchQuery).toBe('Searching query');
  });

  it('should navigate to detail page when viewTodo is called', () => {
    component.viewTodo(10);
    expect(router.navigate).toHaveBeenCalledWith(['/todos', 10]);
  });

  it('should open change modal when handleEditTodo is called', () => {
    component.handleEditTodo(42);
    expect(component.selectedTodoId).toBe(42);
    expect(component.showChangeModal).toBe(true);
  });

  it('should handle delete todo when confirmed', async () => {
    vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

    await component.handleDeleteTodo(5);
    expect(todosService.asyncSetIsTodoDelete).toHaveBeenCalledWith(5);
  });

  it('should not delete todo when confirm dialog is canceled', async () => {
    vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: false } as any);

    await component.handleDeleteTodo(5);
    expect(todosService.asyncSetIsTodoDelete).not.toHaveBeenCalled();
  });

  it('should react to effect when isTodoDeleted changes to true or false', () => {
    // false branch
    todosService.isTodoDeleted.set(false);
    TestBed.flushEffects();

    const loadTodosSpy = vi.spyOn(component, 'loadTodos');
    todosService.isTodoDeleted.set(true);
    TestBed.flushEffects();

    expect(todosService.isTodoDeleted()).toBe(false);
    expect(loadTodosSpy).toHaveBeenCalled();
  });

  it('should render loading state when loadingTodos is true and filteredTodos is empty', () => {
    todosService.todos.set([]);
    component.loadingTodos = true;
    fixture.detectChanges();

    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.textContent).toContain('Memuat daftar todo...');
  });

  it('should render empty state when filteredTodos is empty and not loading', () => {
    todosService.todos.set([]);
    component.loadingTodos = false;
    fixture.detectChanges();

    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.textContent).toContain('Belum ada data todo yang cocok.');
  });

  it('should render todo rows with cover, badges, and actions', () => {
    todosService.todos.set([
      {
        id: 1,
        title: 'Task with cover',
        description: 'Task details',
        cover: 'http://example.com/cover.jpg',
        created_at: '2026-01-01',
        updated_at: '2026-01-02',
        is_finished: true,
      } as any,
      {
        id: 2,
        title: 'Task without cover',
        description: '',
        cover: '',
        created_at: '2026-01-01',
        updated_at: '2026-01-02',
        is_finished: false,
      } as any,
    ]);
    fixture.detectChanges();

    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('[data-testid="todo-row-1"]')).toBeTruthy();
    expect(compiled.querySelector('[data-testid="todo-row-2"]')).toBeTruthy();

    const addBtn = compiled.querySelector('[data-testid="add-todo-btn"]') as HTMLButtonElement;
    addBtn.click();
    expect(component.showAddModal).toBe(true);

    const filterPendingBtn = compiled.querySelector('[data-testid="filter-pending-btn"]') as HTMLButtonElement;
    filterPendingBtn.click();
    fixture.detectChanges();
    expect(component.filter).toBe('0');

    const filterFinishedBtn = compiled.querySelector('[data-testid="filter-finished-btn"]') as HTMLButtonElement;
    filterFinishedBtn.click();
    fixture.detectChanges();
    expect(component.filter).toBe('1');

    const filterAllBtn = compiled.querySelector('[data-testid="filter-all-btn"]') as HTMLButtonElement;
    filterAllBtn.click();
    fixture.detectChanges();
    expect(component.filter).toBe('');

    // Row action buttons
    const viewBtn = compiled.querySelector('[data-testid="view-todo-1"]') as HTMLButtonElement;
    viewBtn.click();
    expect(router.navigate).toHaveBeenCalledWith(['/todos', 1]);

    const editBtn = compiled.querySelector('[data-testid="edit-todo-1"]') as HTMLButtonElement;
    editBtn.click();
    expect(component.selectedTodoId).toBe(1);
    expect(component.showChangeModal).toBe(true);

    vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: false } as any);
    const deleteBtn = compiled.querySelector('[data-testid="delete-todo-1"]') as HTMLButtonElement;
    deleteBtn.click();

    // Modal close events
    const addModalDebug = fixture.debugElement.query(By.css('app-add-modal'));
    addModalDebug?.triggerEventHandler('close', null);
    expect(component.showAddModal).toBe(false);

    const changeModalDebug = fixture.debugElement.query(By.css('app-change-modal'));
    changeModalDebug?.triggerEventHandler('close', null);
    expect(component.showChangeModal).toBe(false);
  });
});
