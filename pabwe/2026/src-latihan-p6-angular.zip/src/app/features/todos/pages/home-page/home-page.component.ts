import { Component, OnInit, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { TodosService } from '../../services/todos.service';
import { UsersService } from '../../../users/services/users.service';
import { formatDate, showConfirmDialog } from '../../../../helpers/tools.helper';
import { AddModalComponent } from '../../modals/add-modal/add-modal.component';
import { ChangeModalComponent } from '../../modals/change-modal/change-modal.component';
import type { Todo } from '../../models/todo.model';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [CommonModule, FormsModule, AddModalComponent, ChangeModalComponent],
  template: `
    @if (usersService.profile()) {
      <div class="space-y-8 animate-in fade-in duration-300">
        <!-- Header Banner -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Daftar Todos
            </h1>
            <p class="text-sm text-slate-500 mt-1">
              Kelola dan pantau semua tugas harian Anda secara terorganisir.
            </p>
          </div>
          <button
            type="button"
            data-testid="add-todo-btn"
            (click)="showAddModal = true"
            class="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 shadow-md shadow-indigo-600/25 transition-all self-start sm:self-auto cursor-pointer"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
            <span>Tambah Todo</span>
          </button>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div class="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex items-center justify-between">
            <div>
              <p class="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Total Todo
              </p>
              <h3 class="text-3xl font-black text-slate-800 mt-1">{{ totalCount }}</h3>
            </div>
            <div class="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
            </div>
          </div>

          <div class="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex items-center justify-between">
            <div>
              <p class="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Todo Selesai
              </p>
              <h3 class="text-3xl font-black text-emerald-600 mt-1">
                {{ finishedCount }}
              </h3>
            </div>
            <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
            </div>
          </div>

          <div class="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex items-center justify-between">
            <div>
              <p class="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Sedang Proses
              </p>
              <h3 class="text-3xl font-black text-amber-600 mt-1">{{ pendingCount }}</h3>
            </div>
            <div class="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            </div>
          </div>
        </div>

        <!-- Table & Controls Section -->
        <div class="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <!-- Filter bar -->
          <div class="p-4 sm:p-5 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="relative flex-1 max-w-md">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
              <input
                type="text"
                data-testid="search-todo-input"
                [(ngModel)]="searchQuery"
                placeholder="Cari judul atau rincian todo..."
                class="w-full pl-10 pr-4 py-2 text-sm rounded-xl border border-slate-200 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
              />
            </div>

            <div class="flex items-center gap-2.5">
              <span class="text-xs font-semibold text-slate-500 uppercase tracking-wide flex items-center gap-1.5">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg> Filter:
              </span>
              <div class="inline-flex rounded-xl bg-slate-100 p-1 text-xs font-semibold text-slate-600">
                <button
                  type="button"
                  data-testid="filter-all-btn"
                  (click)="setFilter('')"
                  [ngClass]="filter === '' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'"
                  class="px-3 py-1.5 rounded-lg transition-all cursor-pointer"
                >
                  Semua
                </button>
                <button
                  type="button"
                  data-testid="filter-pending-btn"
                  (click)="setFilter('0')"
                  [ngClass]="filter === '0' ? 'bg-white text-amber-700 shadow-xs' : 'hover:text-slate-900'"
                  class="px-3 py-1.5 rounded-lg transition-all cursor-pointer"
                >
                  Proses
                </button>
                <button
                  type="button"
                  data-testid="filter-finished-btn"
                  (click)="setFilter('1')"
                  [ngClass]="filter === '1' ? 'bg-white text-emerald-700 shadow-xs' : 'hover:text-slate-900'"
                  class="px-3 py-1.5 rounded-lg transition-all cursor-pointer"
                >
                  Selesai
                </button>
              </div>
            </div>
          </div>

          <!-- Responsive Table -->
          <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-600">
              <thead class="bg-slate-50/80 text-xs uppercase tracking-wider font-semibold text-slate-500 border-b border-slate-100">
                <tr>
                  <th class="px-5 py-3.5 text-center w-16">ID</th>
                  <th class="px-5 py-3.5">Judul</th>
                  <th class="px-5 py-3.5 hidden md:table-cell">Dibuat</th>
                  <th class="px-5 py-3.5 hidden lg:table-cell">Diperbarui</th>
                  <th class="px-5 py-3.5">Status</th>
                  <th class="px-5 py-3.5 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                @if (loadingTodos && filteredTodos.length === 0) {
                  <tr>
                    <td colspan="6" class="px-6 py-12 text-center text-slate-400">
                      <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mx-auto text-indigo-600 animate-spin mb-2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                      <p class="font-medium text-slate-600">Memuat daftar todo...</p>
                    </td>
                  </tr>
                } @else if (filteredTodos.length === 0) {
                  <tr>
                    <td colspan="6" class="px-6 py-12 text-center text-slate-400">
                      <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mx-auto text-slate-300 mb-2"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
                      <p class="font-medium">Belum ada data todo yang cocok.</p>
                    </td>
                  </tr>
                } @else {
                  @for (todo of filteredTodos; track todo.id) {
                    <tr
                      [attr.data-testid]="'todo-row-' + todo.id"
                      class="hover:bg-slate-50/70 transition-colors group"
                    >
                      <td class="px-5 py-4 text-center font-mono text-xs font-bold text-slate-400">
                        #{{ todo.id }}
                      </td>
                      <td class="px-5 py-4">
                        <div class="flex items-center gap-3">
                          @if (todo.cover) {
                            <img
                              [src]="todo.cover"
                              [alt]="todo.title"
                              class="w-10 h-10 rounded-lg object-cover border border-slate-200 shrink-0"
                            />
                          }
                          <div>
                            <p class="font-semibold text-slate-800 leading-snug">
                              {{ todo.title }}
                            </p>
                            @if (todo.description) {
                              <p class="text-xs text-slate-400 line-clamp-1 mt-0.5">
                                {{ todo.description }}
                              </p>
                            }
                          </div>
                        </div>
                      </td>
                      <td class="px-5 py-4 hidden md:table-cell text-xs text-slate-500">
                        {{ formatDate(todo.created_at) }}
                      </td>
                      <td class="px-5 py-4 hidden lg:table-cell text-xs text-slate-500">
                        {{ formatDate(todo.updated_at) }}
                      </td>
                      <td class="px-5 py-4">
                        @if (todo.is_finished) {
                          <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/60">
                            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                            Selesai
                          </span>
                        } @else {
                          <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200/60">
                            <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                            Proses
                          </span>
                        }
                      </td>
                      <td class="px-5 py-4 text-right">
                        <div class="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            [attr.data-testid]="'view-todo-' + todo.id"
                            (click)="viewTodo(todo.id)"
                            class="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                            title="Lihat Detail"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                          </button>
                          <button
                            type="button"
                            [attr.data-testid]="'edit-todo-' + todo.id"
                            (click)="handleEditTodo(todo.id)"
                            class="p-1.5 text-slate-600 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                            title="Ubah Todo"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
                          </button>
                          <button
                            type="button"
                            [attr.data-testid]="'delete-todo-' + todo.id"
                            (click)="handleDeleteTodo(todo.id)"
                            class="p-1.5 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                            title="Hapus Todo"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
                          </button>
                        </div>
                      </td>
                    </tr>
                  }
                }
              </tbody>
            </table>
          </div>
        </div>

        <!-- Modals -->
        <app-add-modal [show]="showAddModal" (close)="showAddModal = false"></app-add-modal>
        <app-change-modal
          [show]="showChangeModal"
          [todoId]="selectedTodoId"
          (close)="showChangeModal = false"
        ></app-change-modal>
      </div>
    }
  `,
})
export class HomePageComponent implements OnInit {
  loadingTodos = false;
  filter = '';
  searchQuery = '';
  showAddModal = false;
  showChangeModal = false;
  selectedTodoId: string | number | null = null;
  formatDate = formatDate;

  constructor(
    public todosService: TodosService,
    public usersService: UsersService,
    private router: Router
  ) {
    effect(() => {
      const isTodoDeleted = this.todosService.isTodoDeleted();
      if (isTodoDeleted) {
        this.todosService.isTodoDeleted.set(false);
        this.loadTodos();
      }
    });
  }

  ngOnInit(): void {
    this.loadTodos();
  }

  loadTodos(): void {
    this.loadingTodos = true;
    this.todosService.asyncSetTodos(this.filter).finally(() => {
      this.loadingTodos = false;
    });
  }

  setFilter(newFilter: string): void {
    this.filter = newFilter;
    this.loadTodos();
  }

  get filteredTodos(): Todo[] {
    const list = this.todosService.todos() || [];
    if (!this.searchQuery.trim()) return list;
    const q = this.searchQuery.toLowerCase();
    return list.filter((todo) => {
      const title = todo.title ? todo.title.toLowerCase() : '';
      const description = todo.description ? todo.description.toLowerCase() : '';
      return title.includes(q) || description.includes(q);
    });
  }

  get totalCount(): number {
    return (this.todosService.todos() || []).length;
  }

  get finishedCount(): number {
    return (this.todosService.todos() || []).filter((t) => t.is_finished).length;
  }

  get pendingCount(): number {
    return this.totalCount - this.finishedCount;
  }

  handleEditTodo(todoId: string | number): void {
    this.selectedTodoId = todoId;
    this.showChangeModal = true;
  }

  viewTodo(todoId: string | number): void {
    this.router.navigate(['/todos', todoId]);
  }

  async handleDeleteTodo(todoId: string | number): Promise<void> {
    const result = await showConfirmDialog('Apakah Anda yakin ingin menghapus todo ini?');
    if (result.isConfirmed) {
      this.todosService.asyncSetIsTodoDelete(todoId);
    }
  }
}
