import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { provideRouter, Router, ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { DetailPageComponent } from './detail-page.component';
import { TodosService } from '../../services/todos.service';
import { UsersService } from '../../../users/services/users.service';
import Swal from 'sweetalert2';

describe('DetailPageComponent', () => {
  let component: DetailPageComponent;
  let fixture: ComponentFixture<DetailPageComponent>;
  let todosService: TodosService;
  let usersService: UsersService;
  let router: Router;

  const mockTodo = {
    id: 10,
    title: 'Detail Test Todo',
    description: 'Markdown **content** here',
    cover: 'http://example.com/cover.jpg',
    created_at: '2026-01-01',
    updated_at: '2026-01-02',
    is_finished: false,
  };

  beforeEach(async () => {
    localStorage.clear();
    await TestBed.configureTestingModule({
      imports: [DetailPageComponent],
      providers: [
        provideRouter([]),
        {
          provide: ActivatedRoute,
          useValue: {
            params: of({ todoId: '10' }),
          },
        },
      ],
    }).compileComponents();

    todosService = TestBed.inject(TodosService);
    usersService = TestBed.inject(UsersService);
    router = TestBed.inject(Router);

    vi.spyOn(router, 'navigate').mockResolvedValue(true as any);
    vi.spyOn(todosService, 'asyncSetTodo').mockResolvedValue(undefined as any);
    vi.spyOn(todosService, 'asyncSetIsTodoDelete').mockResolvedValue(undefined as any);

    usersService.profile.set({
      id: 1,
      name: 'John Doe',
      email: 'john@example.com',
    } as any);
    todosService.todo.set(mockTodo as any);

    fixture = TestBed.createComponent(DetailPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should initialize and load todo by id from route params', () => {
    expect(component).toBeTruthy();
    expect(component.todoId).toBe('10');
    expect(todosService.asyncSetTodo).toHaveBeenCalledWith('10');
  });

  it('should render loading spinner when profile or todo is missing', () => {
    todosService.todo.set(null);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('.animate-spin')).toBeTruthy();

    todosService.todo.set(mockTodo as any);
    usersService.profile.set(null);
    fixture.detectChanges();
    expect(compiled.querySelector('.animate-spin')).toBeTruthy();
  });

  it('should navigate back to home on goBack', () => {
    component.goBack();
    expect(router.navigate).toHaveBeenCalledWith(['/']);
  });

  it('should handle delete when confirmed and todo exists', async () => {
    vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

    await component.handleDelete();
    expect(todosService.asyncSetIsTodoDelete).toHaveBeenCalledWith(10);
  });

  it('should not delete when canceled or when todo is missing', async () => {
    vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: false } as any);

    await component.handleDelete();
    expect(todosService.asyncSetIsTodoDelete).not.toHaveBeenCalled();

    // Now test with isConfirmed: true but todo is null
    vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);
    todosService.todo.set(null);
    await component.handleDelete();
    expect(todosService.asyncSetIsTodoDelete).not.toHaveBeenCalled();
  });

  it('should redirect to home if isTodo is true and todo is null', () => {
    todosService.todo.set(null);
    todosService.isTodo.set(true);
    TestBed.flushEffects();

    expect(todosService.isTodo()).toBe(false);
    expect(router.navigate).toHaveBeenCalledWith(['/']);
  });

  it('should not redirect if isTodo is true but todo exists', () => {
    todosService.todo.set(mockTodo as any);
    todosService.isTodo.set(true);
    TestBed.flushEffects();

    expect(todosService.isTodo()).toBe(false);
  });

  it('should redirect to home when isTodoDeleted changes to true', () => {
    todosService.isTodoDeleted.set(true);
    TestBed.flushEffects();

    expect(todosService.isTodoDeleted()).toBe(false);
    expect(router.navigate).toHaveBeenCalledWith(['/']);
  });

  it('should open and close modals', () => {
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;

    const editCoverBtn = compiled.querySelector('[data-testid="edit-cover-btn"]') as HTMLButtonElement;
    editCoverBtn.click();
    expect(component.showCoverModal).toBe(true);

    const editDetailBtn = compiled.querySelector('[data-testid="edit-detail-todo-btn"]') as HTMLButtonElement;
    editDetailBtn.click();
    expect(component.showEditModal).toBe(true);

    const backLink = compiled.querySelector('[data-testid="back-to-todos-link"]') as HTMLAnchorElement;
    backLink.click();
    expect(router.navigate).toHaveBeenCalledWith(['/']);

    vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: false } as any);
    const deleteBtn = compiled.querySelector('[data-testid="delete-detail-todo-btn"]') as HTMLButtonElement;
    deleteBtn.click();

    // Modal close events
    const coverModalDebug = fixture.debugElement.query(By.css('app-change-cover-modal'));
    coverModalDebug?.triggerEventHandler('close', null);
    expect(component.showCoverModal).toBe(false);

    const editModalDebug = fixture.debugElement.query(By.css('app-change-modal'));
    editModalDebug?.triggerEventHandler('close', null);
    expect(component.showEditModal).toBe(false);
  });

  it('should render finished status badge and fallback when no description or cover', () => {
    todosService.todo.set({
      id: 20,
      title: 'Finished Todo',
      description: '',
      cover: '',
      created_at: '2026-01-01',
      updated_at: '2026-01-02',
      is_finished: true,
    } as any);
    fixture.detectChanges();

    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.textContent).toContain('Selesai');
    expect(compiled.textContent).toContain('Tidak ada deskripsi rinci untuk todo ini.');
    expect(compiled.querySelector('img')).toBeNull();
  });

  it('should not call asyncSetTodo if todoId param is missing in route', () => {
    (component as any).route = { params: of({}) };
    todosService.asyncSetTodo = vi.fn();
    component.ngOnInit();
    expect(todosService.asyncSetTodo).not.toHaveBeenCalled();
  });

  it('should handle false branches of effects in detail-page', () => {
    todosService.isTodo.set(false);
    todosService.isTodoDeleted.set(false);
    TestBed.flushEffects();
  });
});
