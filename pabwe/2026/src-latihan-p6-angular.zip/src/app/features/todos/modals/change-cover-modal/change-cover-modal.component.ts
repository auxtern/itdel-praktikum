import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  effect,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TodosService } from '../../services/todos.service';
import { showErrorDialog } from '../../../../helpers/tools.helper';
import type { Todo } from '../../models/todo.model';

@Component({
  selector: 'app-change-cover-modal',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (show && todo) {
      <div
        data-testid="change-cover-modal"
        class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-200"
      >
        <div
          class="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden transform transition-all"
        >
          <div class="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
            <div class="flex items-center gap-2.5">
              <div class="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7"/><line x1="16" x2="22" y1="5" y2="5"/><line x1="19" x2="19" y1="2" y2="8"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
              </div>
              <h3 class="text-base font-bold text-slate-800">Ubah Cover Todo</h3>
            </div>
            <button
              type="button"
              data-testid="close-cover-modal-btn"
              (click)="onClose()"
              class="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
            </button>
          </div>

          <form (ngSubmit)="handleSave()" class="p-6 space-y-4">
            <div>
              <span class="block text-sm font-semibold text-slate-700 mb-2">
                Pilih Gambar Cover
              </span>
              <label class="flex flex-col items-center justify-center w-full h-44 border-2 border-dashed border-slate-300 hover:border-indigo-500 rounded-2xl cursor-pointer bg-slate-50/50 hover:bg-indigo-50/20 transition-all overflow-hidden relative">
                @if (previewUrl) {
                  <img
                    [src]="previewUrl"
                    alt="Preview"
                    class="w-full h-full object-cover"
                  />
                } @else {
                  <div class="flex flex-col items-center justify-center pt-5 pb-6 text-center px-4">
                    <div class="w-10 h-10 mb-2 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>
                    </div>
                    <p class="text-sm font-semibold text-slate-700">
                      Klik untuk memilih foto
                    </p>
                    <p class="text-xs text-slate-500 mt-1">PNG, JPG, JPEG (Max. 1MB)</p>
                  </div>
                }
                <input
                  type="file"
                  data-testid="cover-file-input"
                  accept=".jpg,.jpeg,.png"
                  (change)="handleFileChange($event)"
                  class="hidden"
                />
              </label>
            </div>

            <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                data-testid="cancel-cover-modal-btn"
                (click)="onClose()"
                [disabled]="loading"
                class="px-4 py-2.5 text-sm font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors"
              >
                Batal
              </button>
              <button
                type="submit"
                data-testid="submit-cover-modal-btn"
                [disabled]="loading"
                class="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-sky-600 hover:bg-sky-700 active:bg-sky-800 rounded-xl shadow-md shadow-sky-600/25 transition-all disabled:opacity-60"
              >
                @if (loading) {
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                  <span>Mengunggah...</span>
                } @else {
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>
                  <span>Unggah Cover</span>
                }
              </button>
            </div>
          </form>
        </div>
      </div>
    }
  `,
})
export class ChangeCoverModalComponent implements OnChanges {
  @Input() show: boolean = false;
  @Input() todo: Todo | null = null;
  @Output() close = new EventEmitter<void>();

  loading: boolean = false;
  file: File | null = null;
  previewUrl: string | null = null;

  constructor(private todosService: TodosService) {
    effect(() => {
      const isTodoChangeCover = this.todosService.isTodoChangeCover();
      const isTodoChangedCover = this.todosService.isTodoChangedCover();
      if (isTodoChangeCover) {
        this.loading = false;
        this.todosService.isTodoChangeCover.set(false);
        if (isTodoChangedCover) {
          this.todosService.isTodoChangedCover.set(false);
          if (this.todo) {
            this.todosService.asyncSetTodo(this.todo.id);
          }
          this.onClose();
        }
      }
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['show']) {
      if (this.show) {
        document.body.style.overflow = 'hidden';
      } else {
        document.body.style.overflow = 'auto';
        this.previewUrl = null;
        this.file = null;
      }
    }
  }

  onClose(): void {
    this.previewUrl = null;
    this.file = null;
    this.close.emit();
  }

  handleFileChange(e: Event): void {
    const target = e.target as HTMLInputElement;
    const selectedFile = target.files?.[0];
    if (!selectedFile) return;

    if (!selectedFile.type.startsWith('image/')) {
      showErrorDialog('Pilih file gambar (JPG/PNG)!');
      return;
    }

    if (selectedFile.size > 1024 * 1024) {
      showErrorDialog('Ukuran gambar maksimal 1MB!');
      return;
    }

    this.file = selectedFile;
    this.previewUrl = URL.createObjectURL(selectedFile);
  }

  handleSave(): void {
    if (!this.file) {
      showErrorDialog('Silakan pilih cover baru!');
      return;
    }

    if (!this.todo) return;

    this.loading = true;
    this.todosService.asyncSetIsTodoChangeCover(this.todo.id, this.file);
  }
}
