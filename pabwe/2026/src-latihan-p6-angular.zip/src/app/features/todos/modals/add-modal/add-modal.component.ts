import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  effect,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TodosService } from '../../services/todos.service';
import { showErrorDialog } from '../../../../helpers/tools.helper';
import { MarkdownEditorComponent } from '../../components/markdown-editor/markdown-editor.component';

@Component({
  selector: 'app-add-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, MarkdownEditorComponent],
  template: `
    @if (show) {
      <div
        data-testid="add-todo-modal"
        class="fixed inset-0 z-50 flex flex-col bg-white animate-in fade-in duration-200 overflow-hidden"
      >
        <!-- Modal Header -->
        <div class="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80 shrink-0">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
            </div>
            <div>
              <h3 class="text-base font-bold text-slate-800">Tambah Todo Baru</h3>
              <p class="text-xs text-slate-500">Buat tugas baru dan tuliskan detailnya dengan format Markdown</p>
            </div>
          </div>
          <button
            type="button"
            data-testid="close-add-modal-btn"
            (click)="onClose()"
            class="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
          </button>
        </div>

        <!-- Modal Form Body -->
        <form (ngSubmit)="handleSave()" class="flex-1 flex flex-col min-h-0 bg-white">
          <div class="flex-1 flex flex-col min-h-0 p-6 md:p-8 space-y-4 w-full">
            <div class="shrink-0">
              <label for="add-todo-title-input" class="block text-sm font-semibold text-slate-700 mb-1.5">
                Judul Todo <span class="text-red-500">*</span>
              </label>
              <input
                id="add-todo-title-input"
                type="text"
                data-testid="add-todo-title-input"
                [(ngModel)]="title"
                name="title"
                placeholder="Contoh: Menyelesaikan Laporan Praktikum"
                class="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all text-sm shadow-xs"
                required
              />
            </div>

            <div class="flex-1 flex flex-col min-h-0">
              <span class="block text-sm font-semibold text-slate-700 mb-1.5 shrink-0">
                Deskripsi (Markdown) <span class="text-red-500">*</span>
              </span>
              <div class="flex-1 min-h-[300px]">
                <app-markdown-editor
                  [value]="description"
                  (valueChange)="description = $event"
                  placeholder="Tuliskan rincian tugas yang perlu diselesaikan dalam format Markdown..."
                  height="100%"
                  textareaTestId="add-todo-description-input"
                ></app-markdown-editor>
              </div>
            </div>
          </div>

          <!-- Modal Footer -->
          <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-200 bg-slate-50/80 shrink-0">
            <button
              type="button"
              data-testid="cancel-add-modal-btn"
              (click)="onClose()"
              [disabled]="loading"
              class="px-5 py-2.5 text-sm font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-200/60 rounded-xl transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              data-testid="submit-add-modal-btn"
              [disabled]="loading"
              class="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-xl shadow-md shadow-indigo-600/25 transition-all disabled:opacity-60"
            >
              @if (loading) {
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                <span>Menyimpan...</span>
              } @else {
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                <span>Tambah Todo</span>
              }
            </button>
          </div>
        </form>
      </div>
    }
  `,
})
export class AddModalComponent implements OnChanges {
  @Input() show: boolean = false;
  @Output() close = new EventEmitter<void>();

  loading: boolean = false;
  title: string = '';
  description: string = '';

  constructor(private todosService: TodosService) {
    effect(() => {
      const isTodoAdd = this.todosService.isTodoAdd();
      const isTodoAdded = this.todosService.isTodoAdded();
      if (isTodoAdd) {
        this.loading = false;
        this.todosService.isTodoAdd.set(false);
        if (isTodoAdded) {
          this.todosService.isTodoAdded.set(false);
          this.todosService.asyncSetTodos();
          this.title = '';
          this.description = '';
          this.onClose();
        }
      }
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['show']) {
      if (this.show) {
        document.body.style.overflow = 'hidden';
      } else {
        document.body.style.overflow = 'auto';
      }
    }
  }

  onClose(): void {
    this.close.emit();
  }

  handleSave(): void {
    if (!this.title.trim()) {
      showErrorDialog('Judul tidak boleh kosong');
      return;
    }
    if (!this.description.trim()) {
      showErrorDialog('Deskripsi tidak boleh kosong');
      return;
    }
    this.loading = true;
    this.todosService.asyncSetIsTodoAdd(this.title.trim(), this.description.trim());
  }
}
