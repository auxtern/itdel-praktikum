import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  effect,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TodosService } from '../../services/todos.service';
import { showErrorDialog } from '../../../../helpers/tools.helper';
import { MarkdownEditorComponent } from '../../components/markdown-editor/markdown-editor.component';

@Component({
  selector: 'app-change-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, MarkdownEditorComponent],
  template: `
    @if (show) {
      <div
        data-testid="edit-todo-modal"
        class="fixed inset-0 z-50 flex flex-col bg-white animate-in fade-in duration-200 overflow-hidden"
      >
        <!-- Modal Header -->
        <div class="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80 shrink-0">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/><path d="m15 5 3 3"/></svg>
            </div>
            <div>
              <h3 class="text-base font-bold text-slate-800">Ubah Data Todo</h3>
              <p class="text-xs text-slate-500">Perbarui judul, status penyelesaian, dan detail deskripsi Markdown</p>
            </div>
          </div>
          <button
            type="button"
            data-testid="close-edit-modal-btn"
            (click)="onClose()"
            class="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
          </button>
        </div>

        <!-- Modal Form Body -->
        <form (ngSubmit)="handleSave()" class="flex-1 flex flex-col min-h-0 bg-white">
          <div class="flex-1 flex flex-col min-h-0 p-6 md:p-8 space-y-4 w-full">
            @if (fetchingTodo) {
              <div class="flex-1 flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="animate-spin text-amber-600"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
              </div>
            } @else {
              <div class="grid grid-cols-1 md:grid-cols-3 gap-4 shrink-0">
                <div class="md:col-span-2">
                  <label for="edit-todo-title-input" class="block text-sm font-semibold text-slate-700 mb-1.5">
                    Judul Todo <span class="text-red-500">*</span>
                  </label>
                  <input
                    id="edit-todo-title-input"
                    type="text"
                    data-testid="edit-todo-title-input"
                    [(ngModel)]="title"
                    name="title"
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all text-sm shadow-xs"
                    required
                  />
                </div>

                <div>
                  <label for="edit-todo-status-select" class="block text-sm font-semibold text-slate-700 mb-1.5">
                    Status Penyelesaian
                  </label>
                  <select
                    id="edit-todo-status-select"
                    data-testid="edit-todo-status-select"
                    [(ngModel)]="isFinished"
                    name="isFinished"
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all text-sm shadow-xs"
                  >
                    <option value="0">Sedang Proses</option>
                    <option value="1">Sudah Selesai</option>
                  </select>
                </div>
              </div>

              <div class="flex-1 flex flex-col min-h-0">
                <span class="block text-sm font-semibold text-slate-700 mb-1.5 shrink-0">
                  Deskripsi (Markdown) <span class="text-red-500">*</span>
                </span>
                <div class="flex-1 min-h-[300px]">
                  <app-markdown-editor
                    [value]="description"
                    (valueChange)="description = $event"
                    placeholder="Tuliskan rincian tugas yang perlu diselesaikan dalam format Markdown..."
                    height="100%"
                    textareaTestId="edit-todo-description-input"
                  ></app-markdown-editor>
                </div>
              </div>
            }
          </div>

          <!-- Modal Footer -->
          <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-200 bg-slate-50/80 shrink-0">
            <button
              type="button"
              data-testid="cancel-edit-modal-btn"
              (click)="onClose()"
              [disabled]="loading"
              class="px-5 py-2.5 text-sm font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-200/60 rounded-xl transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              data-testid="submit-edit-modal-btn"
              [disabled]="loading || fetchingTodo"
              class="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-amber-600 hover:bg-amber-700 active:bg-amber-800 rounded-xl shadow-md shadow-amber-600/25 transition-all disabled:opacity-60"
            >
              @if (loading) {
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                <span>Menyimpan...</span>
              } @else {
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/><path d="m15 5 3 3"/></svg>
                <span>Perbarui Todo</span>
              }
            </button>
          </div>
        </form>
      </div>
    }
  `,
})
export class ChangeModalComponent implements OnChanges {
  @Input() show: boolean = false;
  @Input() todoId: string | number | null = null;
  @Output() close = new EventEmitter<void>();

  loading: boolean = false;
  fetchingTodo: boolean = false;
  title: string = '';
  isFinished: string = '0';
  description: string = '';

  constructor(private todosService: TodosService) {
    effect(() => {
      const isTodoChange = this.todosService.isTodoChange();
      const isTodoChanged = this.todosService.isTodoChanged();
      if (isTodoChange) {
        this.loading = false;
        this.todosService.isTodoChange.set(false);
        if (isTodoChanged) {
          this.todosService.isTodoChanged.set(false);
          this.todosService.asyncSetTodos();
          if (this.todoId) {
            this.todosService.asyncSetTodo(this.todoId);
          }
          this.onClose();
        }
      }
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['show']) {
      if (this.show) {
        document.body.style.overflow = 'hidden';
        if (this.todoId) {
          this.loadTodoData(this.todoId);
        }
      } else {
        document.body.style.overflow = 'auto';
      }
    }
    if (changes['todoId'] && this.show && this.todoId) {
      this.loadTodoData(this.todoId);
    }
  }

  async loadTodoData(id: string | number): Promise<void> {
    this.fetchingTodo = true;
    try {
      const todo = await this.todosService.getTodoById(id);
      if (todo) {
        this.title = todo.title || '';
        this.description = todo.description || '';
        this.isFinished = todo.is_finished ? '1' : '0';
      }
    } catch {
      showErrorDialog('Gagal mengambil data todo');
      this.onClose();
    } finally {
      this.fetchingTodo = false;
    }
  }

  onClose(): void {
    this.close.emit();
  }

  handleSave(): void {
    if (!this.title.trim()) {
      showErrorDialog('Judul tidak boleh kosong');
      return;
    }
    if (!this.description.trim()) {
      showErrorDialog('Deskripsi tidak boleh kosong');
      return;
    }
    if (!this.todoId) return;

    this.loading = true;
    this.todosService.asyncSetIsTodoChange(
      this.todoId,
      this.title.trim(),
      this.description.trim(),
      this.isFinished === '1'
    );
  }
}
