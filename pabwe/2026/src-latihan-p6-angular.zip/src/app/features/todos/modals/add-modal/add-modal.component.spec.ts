import { describe, it, expect, vi, beforeEach } from 'vitest';
import { SimpleChange } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { AddModalComponent } from './add-modal.component';
import { TodosService } from '../../services/todos.service';
import Swal from 'sweetalert2';

describe('AddModalComponent', () => {
  let component: AddModalComponent;
  let fixture: any;
  let todosService: TodosService;

  beforeEach(async () => {
    vi.restoreAllMocks();

    await TestBed.configureTestingModule({
      imports: [AddModalComponent],
    }).compileComponents();

    todosService = TestBed.inject(TodosService);
    fixture = TestBed.createComponent(AddModalComponent);
    component = fixture.componentInstance;
  });

  it('should not render when show is false', () => {
    component.show = false;
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('[data-testid="add-todo-modal"]')).toBeNull();
  });

  it('should render when show is true', () => {
    component.show = true;
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('[data-testid="add-todo-modal"]')).not.toBeNull();

    const closeBtn = el.querySelector('[data-testid="close-add-modal-btn"]') as HTMLElement;
    const cancelBtn = el.querySelector('[data-testid="cancel-add-modal-btn"]') as HTMLElement;
    const emitSpy = vi.spyOn(component.close, 'emit');

    closeBtn.click();
    expect(emitSpy).toHaveBeenCalledTimes(1);

    cancelBtn.click();
    expect(emitSpy).toHaveBeenCalledTimes(2);

    // Markdown editor valueChange
    const editorDebug = fixture.debugElement.query(By.css('app-markdown-editor'));
    editorDebug?.triggerEventHandler('valueChange', 'New Markdown Content');
    expect(component.description).toBe('New Markdown Content');

    // Loading state
    component.loading = true;
    fixture.detectChanges();
    expect(el.textContent).toContain('Menyimpan...');

    // Title ngModelChange and form ngSubmit
    const titleDe = fixture.debugElement.query(By.css('#add-todo-title-input'));
    titleDe?.triggerEventHandler('ngModelChange', 'Typed Title');
    expect(component.title).toBe('Typed Title');

    const form = fixture.debugElement.query(By.css('form'));
    const saveSpy = vi.spyOn(component, 'handleSave');
    form?.triggerEventHandler('ngSubmit', null);
    expect(saveSpy).toHaveBeenCalled();
  });

  it('should validate empty title and empty description', () => {
    const fireSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

    component.title = '   ';
    component.handleSave();
    expect(fireSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Judul tidak boleh kosong' }));

    component.title = 'Valid Title';
    component.description = '   ';
    component.handleSave();
    expect(fireSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Deskripsi tidak boleh kosong' }));
  });

  it('should call asyncSetIsTodoAdd when title and description are valid', () => {
    const addSpy = vi.spyOn(todosService, 'asyncSetIsTodoAdd').mockImplementation(() => Promise.resolve());

    component.title = 'New Todo';
    component.description = 'Detail Description';
    component.handleSave();

    expect(addSpy).toHaveBeenCalledWith('New Todo', 'Detail Description');
    expect(component.loading).toBe(true);
  });

  it('should handle effect when isTodoAdd and isTodoAdded are true, or false', () => {
    const closeSpy = vi.spyOn(component.close, 'emit');
    const refreshSpy = vi.spyOn(todosService, 'asyncSetTodos').mockImplementation(() => Promise.resolve());

    // isTodoAdd is false
    todosService.isTodoAdd.set(false);
    TestBed.flushEffects();

    component.title = 'Title';
    component.description = 'Desc';

    todosService.isTodoAdded.set(true);
    todosService.isTodoAdd.set(true);
    TestBed.flushEffects();

    expect(refreshSpy).toHaveBeenCalled();
    expect(component.title).toBe('');
    expect(component.description).toBe('');
    expect(closeSpy).toHaveBeenCalled();
  });

  it('should handle effect when isTodoAdded is false', () => {
    const closeSpy = vi.spyOn(component.close, 'emit');

    todosService.isTodoAdded.set(false);
    todosService.isTodoAdd.set(true);
    TestBed.flushEffects();

    expect(closeSpy).not.toHaveBeenCalled();
    expect(component.loading).toBe(false);
  });

  it('should toggle body overflow on ngOnChanges, and ignore unrelated changes', () => {
    // unrelated changes
    component.ngOnChanges({});

    component.show = true;
    component.ngOnChanges({
      show: new SimpleChange(false, true, true),
    });
    expect(document.body.style.overflow).toBe('hidden');

    component.show = false;
    component.ngOnChanges({
      show: new SimpleChange(true, false, false),
    });
    expect(document.body.style.overflow).toBe('auto');
  });

  it('should emit close when onClose is called', () => {
    const emitSpy = vi.spyOn(component.close, 'emit');
    component.onClose();
    expect(emitSpy).toHaveBeenCalled();
  });
});
