import { describe, it, expect, vi, beforeEach } from 'vitest';
import { SimpleChange } from '@angular/core';
import { By } from '@angular/platform-browser';
import { TestBed } from '@angular/core/testing';
import { ChangeCoverModalComponent } from './change-cover-modal.component';
import { TodosService } from '../../services/todos.service';
import Swal from 'sweetalert2';

describe('ChangeCoverModalComponent', () => {
  let component: ChangeCoverModalComponent;
  let fixture: any;
  let todosService: TodosService;
  const mockTodo = { id: 1, title: 'Todo Test' } as any;

  beforeEach(async () => {
    (globalThis as any).URL.createObjectURL = vi.fn().mockReturnValue('blob:mock-url');

    await TestBed.configureTestingModule({
      imports: [ChangeCoverModalComponent],
    }).compileComponents();

    todosService = TestBed.inject(TodosService);
    fixture = TestBed.createComponent(ChangeCoverModalComponent);
    component = fixture.componentInstance;
  });

  it('should not render when show is false or todo is null', () => {
    component.show = false;
    component.todo = mockTodo;
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('[data-testid="change-cover-modal"]')).toBeNull();
  });

  it('should render when show is true and todo exists', () => {
    component.show = true;
    component.todo = mockTodo;
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('[data-testid="change-cover-modal"]')).not.toBeNull();

    const closeBtn = el.querySelector('[data-testid="close-cover-modal-btn"]') as HTMLElement;
    const cancelBtn = el.querySelector('[data-testid="cancel-cover-modal-btn"]') as HTMLElement;
    const emitSpy = vi.spyOn(component.close, 'emit');

    closeBtn.click();
    expect(emitSpy).toHaveBeenCalledTimes(1);

    cancelBtn.click();
    expect(emitSpy).toHaveBeenCalledTimes(2);

    const fileInput = el.querySelector('[data-testid="cover-file-input"]') as HTMLInputElement;
    fileInput.dispatchEvent(new Event('change'));
  });

  it('should render preview image when previewUrl exists', () => {
    const freshFixture = TestBed.createComponent(ChangeCoverModalComponent);
    freshFixture.componentInstance.show = true;
    freshFixture.componentInstance.todo = mockTodo;
    freshFixture.componentInstance.previewUrl = 'blob:test';
    freshFixture.detectChanges();
    expect(freshFixture.nativeElement.querySelector('img[alt="Preview"]')).not.toBeNull();
  });

  it('should render loading spinner when loading is true', () => {
    const freshFixture = TestBed.createComponent(ChangeCoverModalComponent);
    freshFixture.componentInstance.show = true;
    freshFixture.componentInstance.todo = mockTodo;
    freshFixture.componentInstance.loading = true;
    freshFixture.detectChanges();
    expect(freshFixture.nativeElement.textContent).toContain('Mengunggah...');
  });

  it('should validate file presence, non-image type, and large size in handleFileChange', () => {
    const fireSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

    // Empty files
    component.handleFileChange({ target: { files: [] } } as any);

    // Bad file type
    const pdfFile = new File(['dummy'], 'doc.pdf', { type: 'application/pdf' });
    component.handleFileChange({ target: { files: [pdfFile] } } as any);
    expect(fireSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Pilih file gambar (JPG/PNG)!' }));

    // Large file (>1MB)
    const largeFile = new File([new Uint8Array(2 * 1024 * 1024)], 'large.png', { type: 'image/png' });
    component.handleFileChange({ target: { files: [largeFile] } } as any);
    expect(fireSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Ukuran gambar maksimal 1MB!' }));

    // Valid file
    const validFile = new File(['valid'], 'photo.jpg', { type: 'image/jpeg' });
    component.handleFileChange({ target: { files: [validFile] } } as any);
    expect(component.file).toBe(validFile);
    expect(component.previewUrl).toBe('blob:mock-url');
  });

  it('should validate missing file in handleSave', () => {
    const fireSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

    component.file = null;
    component.handleSave();
    expect(fireSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Silakan pilih cover baru!' }));
  });

  it('should call asyncSetIsTodoChangeCover on valid save', () => {
    const coverSpy = vi.spyOn(todosService, 'asyncSetIsTodoChangeCover').mockImplementation(() => Promise.resolve());
    const validFile = new File(['valid'], 'photo.jpg', { type: 'image/jpeg' });

    component.todo = mockTodo;
    component.file = validFile;
    component.handleSave();

    expect(coverSpy).toHaveBeenCalledWith(1, validFile);
    expect(component.loading).toBe(true);
  });

  it('should not call asyncSetIsTodoChangeCover if todo is null', () => {
    const coverSpy = vi.spyOn(todosService, 'asyncSetIsTodoChangeCover').mockImplementation(() => Promise.resolve());

    component.todo = null;
    component.file = new File([''], 'p.png', { type: 'image/png' });
    component.handleSave();

    expect(coverSpy).not.toHaveBeenCalled();
  });

  it('should handle effect when isTodoChangeCover and isTodoChangedCover are true with or without todo', () => {
    const closeSpy = vi.spyOn(component.close, 'emit');
    const singleSpy = vi.spyOn(todosService, 'asyncSetTodo').mockImplementation(() => Promise.resolve());

    // isTodoChangeCover is false
    todosService.isTodoChangeCover.set(false);
    TestBed.flushEffects();

    // with todo
    component.todo = mockTodo;
    todosService.isTodoChangedCover.set(true);
    todosService.isTodoChangeCover.set(true);
    TestBed.flushEffects();

    expect(singleSpy).toHaveBeenCalledWith(1);
    expect(closeSpy).toHaveBeenCalled();

    // without todo
    singleSpy.mockClear();
    closeSpy.mockClear();
    component.todo = null;
    todosService.isTodoChangedCover.set(true);
    todosService.isTodoChangeCover.set(true);
    TestBed.flushEffects();

    expect(singleSpy).not.toHaveBeenCalled();
    expect(closeSpy).toHaveBeenCalled();
  });

  it('should handle effect when isTodoChangedCover is false', () => {
    const closeSpy = vi.spyOn(component.close, 'emit');

    todosService.isTodoChangedCover.set(false);
    todosService.isTodoChangeCover.set(true);
    TestBed.flushEffects();

    expect(closeSpy).not.toHaveBeenCalled();
    expect(component.loading).toBe(false);
  });

  it('should submit form via ngSubmit', () => {
    component.show = true;
    component.todo = mockTodo;
    fixture.detectChanges();

    const form = fixture.debugElement.query(By.css('form'));
    const saveSpy = vi.spyOn(component, 'handleSave');
    form?.triggerEventHandler('ngSubmit', null);
    expect(saveSpy).toHaveBeenCalled();
  });

  it('should toggle body overflow on ngOnChanges, and ignore other changes', () => {
    // unrelated changes
    component.ngOnChanges({});

    component.show = true;
    component.ngOnChanges({
      show: new SimpleChange(false, true, true),
    });
    expect(document.body.style.overflow).toBe('hidden');

    component.show = false;
    component.ngOnChanges({
      show: new SimpleChange(true, false, false),
    });
    expect(document.body.style.overflow).toBe('auto');
    expect(component.previewUrl).toBeNull();
    expect(component.file).toBeNull();
  });

  it('should reset state and emit close on onClose', () => {
    const emitSpy = vi.spyOn(component.close, 'emit');
    component.file = new File([''], 'p.png');
    component.previewUrl = 'blob:url';

    component.onClose();

    expect(component.file).toBeNull();
    expect(component.previewUrl).toBeNull();
    expect(emitSpy).toHaveBeenCalled();
  });
});
