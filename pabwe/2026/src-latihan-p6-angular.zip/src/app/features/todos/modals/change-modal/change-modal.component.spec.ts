import { describe, it, expect, vi, beforeEach } from 'vitest';
import { SimpleChange } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ChangeModalComponent } from './change-modal.component';
import { TodosService } from '../../services/todos.service';
import Swal from 'sweetalert2';

describe('ChangeModalComponent', () => {
  let component: ChangeModalComponent;
  let fixture: any;
  let todosService: TodosService;
  const mockTodo = {
    id: 1,
    title: 'Initial Title',
    description: 'Initial Desc',
    is_finished: 0,
  };

  beforeEach(async () => {
    vi.restoreAllMocks();

    await TestBed.configureTestingModule({
      imports: [ChangeModalComponent],
    }).compileComponents();

    todosService = TestBed.inject(TodosService);
    fixture = TestBed.createComponent(ChangeModalComponent);
    component = fixture.componentInstance;
  });

  it('should not render when show is false', () => {
    component.show = false;
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('[data-testid="edit-todo-modal"]')).toBeNull();
  });

  it('should render and load todo data when show is true', async () => {
    vi.spyOn(todosService, 'getTodoById').mockResolvedValue(mockTodo);

    component.show = true;
    component.todoId = 1;
    await component.loadTodoData(1);
    fixture.detectChanges();

    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('[data-testid="edit-todo-modal"]')).not.toBeNull();
    expect(component.title).toBe('Initial Title');
    expect(component.description).toBe('Initial Desc');
    expect(component.isFinished).toBe('0');

    const closeBtn = el.querySelector('[data-testid="close-edit-modal-btn"]') as HTMLElement;
    const cancelBtn = el.querySelector('[data-testid="cancel-edit-modal-btn"]') as HTMLElement;
    const emitSpy = vi.spyOn(component.close, 'emit');

    closeBtn.click();
    expect(emitSpy).toHaveBeenCalledTimes(1);

    cancelBtn.click();
    expect(emitSpy).toHaveBeenCalledTimes(2);

    const editorDebug = fixture.debugElement.query(By.css('app-markdown-editor'));
    editorDebug?.triggerEventHandler('valueChange', 'Updated Markdown Desc');
    expect(component.description).toBe('Updated Markdown Desc');

    // Title & status ngModelChange and form ngSubmit
    const titleDe = fixture.debugElement.query(By.css('#edit-todo-title-input'));
    titleDe?.triggerEventHandler('ngModelChange', 'Updated Title Value');
    expect(component.title).toBe('Updated Title Value');

    const statusDe = fixture.debugElement.query(By.css('#edit-todo-status-select'));
    statusDe?.triggerEventHandler('ngModelChange', '1');
    expect(component.isFinished).toBe('1');

    const form = fixture.debugElement.query(By.css('form'));
    const saveSpy = vi.spyOn(component, 'handleSave');
    form?.triggerEventHandler('ngSubmit', null);
    expect(saveSpy).toHaveBeenCalled();

    // fetchingTodo spinner
    component.fetchingTodo = true;
    fixture.detectChanges();
    expect(el.querySelector('.animate-spin')).not.toBeNull();
  });

  it('should render loading state on submit button during save', () => {
    component.show = true;
    component.todoId = 1;
    component.title = 'Title';
    component.description = 'Desc';
    component.isFinished = '0';
    vi.spyOn(todosService, 'asyncSetIsTodoChange').mockReturnValue(new Promise(() => {}));
    component.handleSave();
    fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('Menyimpan...');
  });

  it('should handle loadTodoData failure and call onClose', async () => {
    vi.spyOn(todosService, 'getTodoById').mockRejectedValue(new Error('fail'));
    const fireSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);
    const closeSpy = vi.spyOn(component.close, 'emit');

    await component.loadTodoData(1);

    expect(fireSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Gagal mengambil data todo' }));
    expect(closeSpy).toHaveBeenCalled();
  });

  it('should handle loadTodoData with empty title/description and finished todo, and when todo is null', async () => {
    vi.spyOn(todosService, 'getTodoById').mockResolvedValue({
      id: 1,
      title: '',
      description: '',
      is_finished: 1,
    });

    await component.loadTodoData(1);

    expect(component.title).toBe('');
    expect(component.description).toBe('');
    expect(component.isFinished).toBe('1');

    // when todo is null
    vi.spyOn(todosService, 'getTodoById').mockResolvedValue(null as any);
    await component.loadTodoData(2);
  });

  it('should validate empty title and description in handleSave', () => {
    const fireSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

    component.title = '   ';
    component.handleSave();
    expect(fireSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Judul tidak boleh kosong' }));

    component.title = 'Valid';
    component.description = '   ';
    component.handleSave();
    expect(fireSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Deskripsi tidak boleh kosong' }));
  });

  it('should call asyncSetIsTodoChange when fields are valid', () => {
    const changeSpy = vi.spyOn(todosService, 'asyncSetIsTodoChange').mockImplementation(() => Promise.resolve());

    component.todoId = 1;
    component.title = 'Updated Title';
    component.description = 'Updated Desc';
    component.isFinished = '1';

    component.handleSave();

    expect(changeSpy).toHaveBeenCalledWith(1, 'Updated Title', 'Updated Desc', true);
    expect(component.loading).toBe(true);
  });

  it('should not call asyncSetIsTodoChange when todoId is null', () => {
    const changeSpy = vi.spyOn(todosService, 'asyncSetIsTodoChange').mockImplementation(() => Promise.resolve());

    component.todoId = null;
    component.title = 'Title';
    component.description = 'Desc';
    component.handleSave();

    expect(changeSpy).not.toHaveBeenCalled();
  });

  it('should handle effect when isTodoChange and isTodoChanged are true with or without todoId', () => {
    const closeSpy = vi.spyOn(component.close, 'emit');
    const refreshSpy = vi.spyOn(todosService, 'asyncSetTodos').mockImplementation(() => Promise.resolve());
    const singleSpy = vi.spyOn(todosService, 'asyncSetTodo').mockImplementation(() => Promise.resolve());

    // isTodoChange is false
    todosService.isTodoChange.set(false);
    TestBed.flushEffects();

    // with todoId
    component.todoId = 1;
    todosService.isTodoChanged.set(true);
    todosService.isTodoChange.set(true);
    TestBed.flushEffects();

    expect(refreshSpy).toHaveBeenCalled();
    expect(singleSpy).toHaveBeenCalledWith(1);
    expect(closeSpy).toHaveBeenCalled();

    // without todoId
    singleSpy.mockClear();
    closeSpy.mockClear();
    component.todoId = null;
    todosService.isTodoChanged.set(true);
    todosService.isTodoChange.set(true);
    TestBed.flushEffects();

    expect(singleSpy).not.toHaveBeenCalled();
    expect(closeSpy).toHaveBeenCalled();
  });

  it('should handle effect when isTodoChanged is false', () => {
    const closeSpy = vi.spyOn(component.close, 'emit');

    todosService.isTodoChanged.set(false);
    todosService.isTodoChange.set(true);
    TestBed.flushEffects();

    expect(closeSpy).not.toHaveBeenCalled();
    expect(component.loading).toBe(false);
  });

  it('should toggle body overflow and loadTodoData on ngOnChanges', () => {
    const loadSpy = vi.spyOn(component, 'loadTodoData').mockImplementation(() => Promise.resolve());

    // unrelated changes
    component.ngOnChanges({});

    // show true without todoId
    component.show = true;
    component.todoId = null;
    component.ngOnChanges({
      show: new SimpleChange(false, true, true),
    });
    expect(loadSpy).not.toHaveBeenCalled();

    // show true with todoId
    component.todoId = 1;
    component.ngOnChanges({
      show: new SimpleChange(false, true, true),
    });
    expect(document.body.style.overflow).toBe('hidden');
    expect(loadSpy).toHaveBeenCalledWith(1);

    // show false
    component.show = false;
    component.ngOnChanges({
      show: new SimpleChange(true, false, false),
    });
    expect(document.body.style.overflow).toBe('auto');

    // todoId change when show is false
    loadSpy.mockClear();
    component.show = false;
    component.todoId = 2;
    component.ngOnChanges({
      todoId: new SimpleChange(1, 2, false),
    });
    expect(loadSpy).not.toHaveBeenCalled();

    // todoId change when show is true
    component.show = true;
    component.todoId = 2;
    component.ngOnChanges({
      todoId: new SimpleChange(1, 2, false),
    });
    expect(loadSpy).toHaveBeenCalledWith(2);
  });

  it('should emit close when onClose is called', () => {
    const emitSpy = vi.spyOn(component.close, 'emit');
    component.onClose();
    expect(emitSpy).toHaveBeenCalled();
  });
});
