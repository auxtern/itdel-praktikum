export interface Todo {
  id: number | string;
  title: string;
  description: string;
  is_finished: boolean | number;
  cover?: string | null;
  created_at?: string;
  updated_at?: string;
}
