export interface LoginResponse {
  token: string;
  user?: any;
}

export interface RegisterResponse {
  status: string;
  message: string;
}
