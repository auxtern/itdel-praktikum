import { describe, it, expect, vi, beforeEach } from 'vitest';
import { AuthService } from './auth.service';
import ApiHelper from '../../../helpers/api.helper';
import Swal from 'sweetalert2';

describe('AuthService', () => {
  let service: AuthService;

  beforeEach(() => {
    vi.restoreAllMocks();
    service = new AuthService();
  });

  describe('postRegister', () => {
    it('should return message on success', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', message: 'User registered' }), { status: 200 })
      );

      const msg = await service.postRegister('Test', 'test@delcom.org', 'password123');
      expect(msg).toBe('User registered');
    });

    it('should throw formatted error when response fails with validation data object', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(
          JSON.stringify({
            status: 'error',
            message: 'Validasi gagal',
            data: { email: ['Email sudah terdaftar'], name: ['Nama minimal 3 karakter'] },
          }),
          { status: 400 }
        )
      );

      await expect(service.postRegister('T', 'test@delcom.org', '123')).rejects.toThrow(
        'Validasi gagal: Email sudah terdaftar, Nama minimal 3 karakter'
      );
    });

    it('should throw base error message when response fails without data object', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 400 })
      );

      await expect(service.postRegister('T', 'test@delcom.org', '123')).rejects.toThrow(
        'Gagal melakukan pendaftaran'
      );
    });
  });

  describe('postLogin', () => {
    it('should return token data on success', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', data: { token: 'mock-token' } }), { status: 200 })
      );

      const res = await service.postLogin('test@delcom.org', 'password123');
      expect(res).toEqual({ token: 'mock-token' });
    });

    it('should throw error when login fails', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'Kredensial tidak valid' }), { status: 401 })
      );

      await expect(service.postLogin('bad@delcom.org', 'wrong')).rejects.toThrow('Kredensial tidak valid');
    });

    it('should throw default fallback error when login fails without message', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 401 })
      );

      await expect(service.postLogin('bad@delcom.org', 'wrong')).rejects.toThrow('Gagal login');
    });
  });

  describe('postLogout', () => {
    it('should return message on logout success', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', message: 'Logout berhasil' }), { status: 200 })
      );

      const msg = await service.postLogout();
      expect(msg).toBe('Logout berhasil');
    });

    it('should throw error when logout fails', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'Logout gagal' }), { status: 500 })
      );

      await expect(service.postLogout()).rejects.toThrow('Logout gagal');
    });

    it('should throw default fallback error when logout fails without message', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 500 })
      );

      await expect(service.postLogout()).rejects.toThrow('Gagal logout');
    });
  });

  describe('asyncSetIsAuthLogin', () => {
    it('should set isAuthLogin true and save token on success', async () => {
      vi.spyOn(service, 'postLogin').mockResolvedValue({ token: 'saved-token' });
      const putTokenSpy = vi.spyOn(ApiHelper, 'putAccessToken').mockImplementation(() => {});

      await service.asyncSetIsAuthLogin('test@delcom.org', 'pass');

      expect(putTokenSpy).toHaveBeenCalledWith('saved-token');
      expect(service.isAuthLogin()).toBe(true);
    });

    it('should set isAuthLogin false and show error on failure', async () => {
      vi.spyOn(service, 'postLogin').mockRejectedValue(new Error('Login error'));
      const errorSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncSetIsAuthLogin('test@delcom.org', 'pass');

      expect(service.isAuthLogin()).toBe(false);
      expect(errorSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Login error' }));
    });
  });

  describe('asyncSetIsAuthRegister', () => {
    it('should set isAuthRegister true and show success dialog on success', async () => {
      vi.spyOn(service, 'postRegister').mockResolvedValue('Berhasil daftar');
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncSetIsAuthRegister('Name', 'test@delcom.org', 'pass');

      expect(service.isAuthRegister()).toBe(true);
      expect(successSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Berhasil daftar' }));
    });

    it('should set isAuthRegister false and show error on failure', async () => {
      vi.spyOn(service, 'postRegister').mockRejectedValue(new Error('Register error'));
      const errorSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncSetIsAuthRegister('Name', 'test@delcom.org', 'pass');

      expect(service.isAuthRegister()).toBe(false);
      expect(errorSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Register error' }));
    });
  });

  describe('asyncSetIsAuthLogout', () => {
    it('should clear token and set isAuthLogout true on success', async () => {
      vi.spyOn(service, 'postLogout').mockResolvedValue('Logout berhasil');
      const putTokenSpy = vi.spyOn(ApiHelper, 'putAccessToken').mockImplementation(() => {});

      await service.asyncSetIsAuthLogout();

      expect(putTokenSpy).toHaveBeenCalledWith('');
      expect(service.isAuthLogout()).toBe(true);
    });

    it('should clear token and set isAuthLogout true even when postLogout fails', async () => {
      vi.spyOn(service, 'postLogout').mockRejectedValue(new Error('Network error'));
      const putTokenSpy = vi.spyOn(ApiHelper, 'putAccessToken').mockImplementation(() => {});

      await service.asyncSetIsAuthLogout();

      expect(putTokenSpy).toHaveBeenCalledWith('');
      expect(service.isAuthLogout()).toBe(true);
    });
  });
});
