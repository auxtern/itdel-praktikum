import { Injectable, signal } from '@angular/core';
import ApiHelper, { BASE_URL } from '../../../helpers/api.helper';
import { showErrorDialog, showSuccessDialog } from '../../../helpers/tools.helper';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private authUrl = `${BASE_URL}/auth`;

  isAuthLogin = signal<boolean>(false);
  isAuthRegister = signal<boolean>(false);
  isAuthLogout = signal<boolean>(false);

  async postRegister(name: string, email: string, password: string): Promise<string> {
    const response = await ApiHelper.fetchData(`${this.authUrl}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });

    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      const errorDetails =
        result.data && typeof result.data === 'object'
          ? Object.values(result.data).flat().join(', ')
          : '';
      const baseMsg = result.message || 'Gagal melakukan pendaftaran';
      throw new Error(errorDetails ? `${baseMsg}: ${errorDetails}` : baseMsg);
    }
    return result.message;
  }

  async postLogin(email: string, password: string): Promise<{ token: string }> {
    const response = await ApiHelper.fetchData(`${this.authUrl}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal login');
    }
    return result.data;
  }

  async postLogout(): Promise<string> {
    const response = await ApiHelper.fetchData(`${this.authUrl}/logout`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });

    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal logout');
    }
    return result.message;
  }

  async asyncSetIsAuthLogin(email: string, password: string) {
    try {
      const data = await this.postLogin(email, password);
      ApiHelper.putAccessToken(data.token);
      this.isAuthLogin.set(true);
    } catch (error: any) {
      this.isAuthLogin.set(false);
      showErrorDialog(error.message);
    }
  }

  async asyncSetIsAuthRegister(name: string, email: string, password: string) {
    try {
      const message = await this.postRegister(name, email, password);
      this.isAuthRegister.set(true);
      showSuccessDialog(message);
    } catch (error: any) {
      this.isAuthRegister.set(false);
      showErrorDialog(error.message);
    }
  }

  async asyncSetIsAuthLogout() {
    try {
      await this.postLogout();
    } catch {
      // Continue clearing local session
    } finally {
      ApiHelper.putAccessToken('');
      this.isAuthLogout.set(true);
    }
  }
}
