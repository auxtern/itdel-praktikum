import { Component, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { UsersService } from '../../../users/services/users.service';
import ApiHelper from '../../../../helpers/api.helper';

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <form (ngSubmit)="onSubmitHandler()" class="space-y-4">
      <div>
        <label for="login-email-input" class="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
          Alamat Email
        </label>
        <div class="relative">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
          <input
            type="email"
            id="login-email-input"
            data-testid="login-email-input"
            [(ngModel)]="email"
            name="email"
            placeholder="nama@email.com"
            class="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
            required
          />
        </div>
      </div>

      <div>
        <label for="login-password-input" class="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
          Kata Sandi
        </label>
        <div class="relative">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          <input
            type="password"
            id="login-password-input"
            data-testid="login-password-input"
            [(ngModel)]="password"
            name="password"
            placeholder="••••••••"
            class="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
            required
          />
        </div>
      </div>

      <div class="pt-2">
        <button
          type="submit"
          id="login-submit-button"
          data-testid="login-submit-button"
          [disabled]="loading"
          class="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-xl shadow-md shadow-indigo-600/25 transition-all disabled:opacity-60 cursor-pointer"
        >
          @if (loading) {
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
            <span>Sedang Masuk...</span>
          } @else {
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" x2="3" y1="12" y2="12"/></svg>
            <span>Masuk Sekarang</span>
          }
        </button>
      </div>
    </form>
  `,
})
export class LoginPageComponent {
  email = '';
  password = '';
  loading = false;

  constructor(
    private authService: AuthService,
    private usersService: UsersService,
    private router: Router
  ) {
    effect(() => {
      const isAuthLogin = this.authService.isAuthLogin();
      if (isAuthLogin) {
        const token = ApiHelper.getAccessToken();
        if (token) {
          this.usersService.asyncSetProfile();
        } else {
          this.loading = false;
          this.authService.isAuthLogin.set(false);
        }
      }
    });

    effect(() => {
      const isProfile = this.usersService.isProfile();
      if (isProfile) {
        this.loading = false;
        this.authService.isAuthLogin.set(false);
        this.usersService.isProfile.set(false);
        if (this.usersService.profile()) {
          this.router.navigate(['/']);
        }
      }
    });
  }

  async onSubmitHandler(): Promise<void> {
    this.loading = true;
    try {
      await this.authService.asyncSetIsAuthLogin(this.email, this.password);
      if (!ApiHelper.getAccessToken()) {
        this.loading = false;
      }
    } catch {
      this.loading = false;
    }
  }
}
