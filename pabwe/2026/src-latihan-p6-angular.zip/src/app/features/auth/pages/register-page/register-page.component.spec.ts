import { describe, it, expect, vi, beforeEach } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Router, provideRouter } from '@angular/router';
import { RegisterPageComponent } from './register-page.component';
import { AuthService } from '../../services/auth.service';
import Swal from 'sweetalert2';

describe('RegisterPageComponent', () => {
  let component: RegisterPageComponent;
  let fixture: any;
  let authService: AuthService;
  let router: Router;

  beforeEach(async () => {
    vi.restoreAllMocks();

    await TestBed.configureTestingModule({
      imports: [RegisterPageComponent],
      providers: [provideRouter([])],
    }).compileComponents();

    authService = TestBed.inject(AuthService);
    router = TestBed.inject(Router);
    fixture = TestBed.createComponent(RegisterPageComponent);
    component = fixture.componentInstance;
  });

  it('should render form inputs and submit button, and update ngModel on change', () => {
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('#register-name-input')).not.toBeNull();
    expect(el.querySelector('#register-email-input')).not.toBeNull();
    expect(el.querySelector('#register-password-input')).not.toBeNull();
    expect(el.querySelector('#register-password-confirm-input')).not.toBeNull();

    fixture.debugElement.query(By.css('#register-name-input')).triggerEventHandler('ngModelChange', 'New Name');
    fixture.debugElement.query(By.css('#register-email-input')).triggerEventHandler('ngModelChange', 'new@delcom.org');
    fixture.debugElement.query(By.css('#register-password-input')).triggerEventHandler('ngModelChange', 'pass123');
    fixture.debugElement.query(By.css('#register-password-confirm-input')).triggerEventHandler('ngModelChange', 'pass123');
    fixture.detectChanges();

    expect(component.name).toBe('New Name');
    expect(component.email).toBe('new@delcom.org');
    expect(component.password).toBe('pass123');
    expect(component.passwordConfirmation).toBe('pass123');
  });

  it('should render loading state on submit button during submit', () => {
    component.name = 'Valid';
    component.email = 'valid@example.com';
    component.password = 'password123';
    component.passwordConfirmation = 'password123';
    vi.spyOn(authService, 'asyncSetIsAuthRegister').mockReturnValue(new Promise(() => {}));
    component.onSubmitHandler();
    fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('Sedang Mendaftar...');
  });

  it('should validate empty fields and mismatched confirmation', async () => {
    const fireSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

    // Empty name
    component.name = '';
    await component.onSubmitHandler();
    expect(fireSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Nama lengkap wajib diisi!' }));

    // Empty email
    component.name = 'Valid Name';
    component.email = '';
    await component.onSubmitHandler();
    expect(fireSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Email wajib diisi!' }));

    // Empty password
    component.email = 'valid@delcom.org';
    component.password = '';
    await component.onSubmitHandler();
    expect(fireSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Kata sandi wajib diisi!' }));

    // Mismatched confirmation
    component.password = 'pass123';
    component.passwordConfirmation = 'mismatch';
    await component.onSubmitHandler();
    expect(fireSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Konfirmasi kata sandi tidak cocok!' }));
  });

  it('should call asyncSetIsAuthRegister when all fields are valid via form submit', async () => {
    const registerSpy = vi.spyOn(authService, 'asyncSetIsAuthRegister').mockImplementation(() => Promise.resolve());

    component.name = 'Abdullah';
    component.email = 'abdul@delcom.org';
    component.password = 'password123';
    component.passwordConfirmation = 'password123';

    const form = fixture.debugElement.query(By.css('form'));
    form.triggerEventHandler('ngSubmit', null);
    await fixture.whenStable();

    expect(registerSpy).toHaveBeenCalledWith('Abdullah', 'abdul@delcom.org', 'password123');
    expect(component.loading).toBe(false);
  });

  it('should handle isAuthRegister effect and navigate to /auth/login or do nothing when false', () => {
    const navSpy = vi.spyOn(router, 'navigate').mockImplementation(() => Promise.resolve(true));

    // false branch
    authService.isAuthRegister.set(false);
    TestBed.flushEffects();
    expect(navSpy).not.toHaveBeenCalled();

    // true branch
    component.loading = true;
    authService.isAuthRegister.set(true);
    TestBed.flushEffects();

    expect(component.loading).toBe(false);
    expect(authService.isAuthRegister()).toBe(false);
    expect(navSpy).toHaveBeenCalledWith(['/auth/login']);
  });
});
