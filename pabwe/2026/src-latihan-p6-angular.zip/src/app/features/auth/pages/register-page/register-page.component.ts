import { Component, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { showErrorDialog } from '../../../../helpers/tools.helper';

@Component({
  selector: 'app-register-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <form (ngSubmit)="onSubmitHandler()" class="space-y-4">
      <div>
        <label for="register-name-input" class="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
          Nama Lengkap
        </label>
        <div class="relative">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          <input
            type="text"
            id="register-name-input"
            data-testid="register-name-input"
            [(ngModel)]="name"
            name="name"
            placeholder="Nama Lengkap"
            class="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
            required
          />
        </div>
      </div>

      <div>
        <label for="register-email-input" class="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
          Alamat Email
        </label>
        <div class="relative">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
          <input
            type="email"
            id="register-email-input"
            data-testid="register-email-input"
            [(ngModel)]="email"
            name="email"
            placeholder="nama@email.com"
            class="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
            required
          />
        </div>
      </div>

      <div>
        <label for="register-password-input" class="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
          Kata Sandi
        </label>
        <div class="relative">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          <input
            type="password"
            id="register-password-input"
            data-testid="register-password-input"
            [(ngModel)]="password"
            name="password"
            placeholder="••••••••"
            class="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
            required
          />
        </div>
      </div>

      <div>
        <label for="register-password-confirm-input" class="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
          Konfirmasi Kata Sandi
        </label>
        <div class="relative">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          <input
            type="password"
            id="register-password-confirm-input"
            data-testid="register-password-confirm-input"
            [(ngModel)]="passwordConfirmation"
            name="passwordConfirmation"
            placeholder="••••••••"
            class="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
            required
          />
        </div>
      </div>

      <div class="pt-2">
        <button
          type="submit"
          id="register-submit-button"
          data-testid="register-submit-button"
          [disabled]="loading"
          class="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-xl shadow-md shadow-indigo-600/25 transition-all disabled:opacity-60 cursor-pointer"
        >
          @if (loading) {
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
            <span>Sedang Mendaftar...</span>
          } @else {
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" x2="19" y1="8" y2="14"/><line x1="22" x2="16" y1="11" y2="11"/></svg>
            <span>Daftar Sekarang</span>
          }
        </button>
      </div>
    </form>
  `,
})
export class RegisterPageComponent {
  name = '';
  email = '';
  password = '';
  passwordConfirmation = '';
  loading = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {
    effect(() => {
      const isAuthRegister = this.authService.isAuthRegister();
      if (isAuthRegister) {
        this.loading = false;
        this.authService.isAuthRegister.set(false);
        this.router.navigate(['/auth/login']);
      }
    });
  }

  async onSubmitHandler(): Promise<void> {
    if (!this.name.trim()) {
      showErrorDialog('Nama lengkap wajib diisi!');
      return;
    }
    if (!this.email.trim()) {
      showErrorDialog('Email wajib diisi!');
      return;
    }
    if (!this.password) {
      showErrorDialog('Kata sandi wajib diisi!');
      return;
    }
    if (this.password !== this.passwordConfirmation) {
      showErrorDialog('Konfirmasi kata sandi tidak cocok!');
      return;
    }

    this.loading = true;
    try {
      await this.authService.asyncSetIsAuthRegister(
        this.name.trim(),
        this.email.trim(),
        this.password
      );
    } finally {
      this.loading = false;
    }
  }
}
