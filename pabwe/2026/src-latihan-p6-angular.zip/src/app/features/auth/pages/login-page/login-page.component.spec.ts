import { describe, it, expect, vi, beforeEach } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Router, provideRouter } from '@angular/router';
import { LoginPageComponent } from './login-page.component';
import { AuthService } from '../../services/auth.service';
import { UsersService } from '../../../users/services/users.service';
import ApiHelper from '../../../../helpers/api.helper';

describe('LoginPageComponent', () => {
  let component: LoginPageComponent;
  let fixture: any;
  let authService: AuthService;
  let usersService: UsersService;
  let router: Router;

  beforeEach(async () => {
    vi.restoreAllMocks();

    await TestBed.configureTestingModule({
      imports: [LoginPageComponent],
      providers: [provideRouter([])],
    }).compileComponents();

    authService = TestBed.inject(AuthService);
    usersService = TestBed.inject(UsersService);
    router = TestBed.inject(Router);
    fixture = TestBed.createComponent(LoginPageComponent);
    component = fixture.componentInstance;
  });

  it('should render form controls and submit button and update ngModel on input', async () => {
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('#login-email-input')).not.toBeNull();
    expect(el.querySelector('#login-password-input')).not.toBeNull();
    expect(el.querySelector('#login-submit-button')).not.toBeNull();

    const emailDe = fixture.debugElement.query(By.css('#login-email-input'));
    const passDe = fixture.debugElement.query(By.css('#login-password-input'));
    emailDe.triggerEventHandler('ngModelChange', 'typed@example.com');
    passDe.triggerEventHandler('ngModelChange', 'secret');
    fixture.detectChanges();

    expect(component.email).toBe('typed@example.com');
    expect(component.password).toBe('secret');
  });

  it('should render loading state on submit button during submit', () => {
    vi.spyOn(authService, 'asyncSetIsAuthLogin').mockReturnValue(new Promise(() => {}));
    component.onSubmitHandler();
    fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('Sedang Masuk...');
  });

  it('should submit login on onSubmitHandler and set loading', async () => {
    const loginSpy = vi.spyOn(authService, 'asyncSetIsAuthLogin').mockImplementation(() => Promise.resolve());
    vi.spyOn(ApiHelper, 'getAccessToken').mockReturnValue('token');

    component.email = 'test@delcom.org';
    component.password = 'pass123';
    
    // trigger via form ngSubmit
    const form = fixture.debugElement.query(By.css('form'));
    form.triggerEventHandler('ngSubmit', null);

    expect(loginSpy).toHaveBeenCalledWith('test@delcom.org', 'pass123');
    expect(component.loading).toBe(true);
  });

  it('should set loading false on onSubmitHandler if no token is returned or error thrown', async () => {
    vi.spyOn(authService, 'asyncSetIsAuthLogin').mockImplementation(() => Promise.resolve());
    vi.spyOn(ApiHelper, 'getAccessToken').mockReturnValue(null);

    await component.onSubmitHandler();
    expect(component.loading).toBe(false);

    vi.spyOn(authService, 'asyncSetIsAuthLogin').mockRejectedValue(new Error('fail'));
    await component.onSubmitHandler();
    expect(component.loading).toBe(false);
  });

  it('should handle isAuthLogin effect when token exists vs does not exist', () => {
    const setProfileSpy = vi.spyOn(usersService, 'asyncSetProfile').mockImplementation(() => Promise.resolve());
    vi.spyOn(ApiHelper, 'getAccessToken').mockReturnValue('token');

    authService.isAuthLogin.set(true);
    TestBed.flushEffects();
    expect(setProfileSpy).toHaveBeenCalled();

    authService.isAuthLogin.set(false);
    TestBed.flushEffects();

    vi.spyOn(ApiHelper, 'getAccessToken').mockReturnValue(null);
    component.loading = true;
    authService.isAuthLogin.set(true);
    TestBed.flushEffects();
    expect(component.loading).toBe(false);
  });

  it('should handle isProfile effect and navigate when profile exists or not navigate when profile is null', () => {
    const navSpy = vi.spyOn(router, 'navigate').mockImplementation(() => Promise.resolve(true));
    usersService.profile.set({ id: 1, name: 'User' } as any);

    usersService.isProfile.set(true);
    TestBed.flushEffects();

    expect(navSpy).toHaveBeenCalledWith(['/']);
    expect(component.loading).toBe(false);

    // when profile is null
    navSpy.mockClear();
    usersService.profile.set(null);
    usersService.isProfile.set(true);
    TestBed.flushEffects();
    expect(navSpy).not.toHaveBeenCalled();
  });
});
