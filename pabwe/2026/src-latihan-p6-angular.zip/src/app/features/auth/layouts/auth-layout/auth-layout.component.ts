import { Component, OnInit, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { UsersService } from '../../../users/services/users.service';
import ApiHelper from '../../../../helpers/api.helper';

@Component({
  selector: 'app-auth-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink],
  template: `
    <div class="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50/40 to-slate-100 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div class="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div class="inline-flex w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 to-cyan-500 items-center justify-center text-white shadow-xl shadow-indigo-500/25 mb-3">
          <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
        </div>
        <h2 class="text-3xl font-extrabold text-slate-900 tracking-tight">
          Delcom Todo
        </h2>
        <p class="mt-1 text-sm text-slate-500">
          Aplikasi Pengelola Tugas & Autentikasi Modern (Angular)
        </p>
      </div>

      <div class="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
        <div class="bg-white py-8 px-6 sm:px-10 shadow-xl shadow-slate-200/50 rounded-3xl border border-slate-100">
          <!-- Tabs -->
          <div class="flex rounded-2xl bg-slate-100 p-1 mb-6">
            <a
              routerLink="/auth/login"
              [class]="isLoginActive() ? 'flex-1 py-2 text-center text-sm font-semibold rounded-xl transition-all bg-white text-indigo-700 shadow-xs cursor-pointer' : 'flex-1 py-2 text-center text-sm font-semibold rounded-xl transition-all text-slate-600 hover:text-slate-900 cursor-pointer'"
            >
              Masuk Akun
            </a>
            <a
              routerLink="/auth/register"
              [class]="!isLoginActive() ? 'flex-1 py-2 text-center text-sm font-semibold rounded-xl transition-all bg-white text-indigo-700 shadow-xs cursor-pointer' : 'flex-1 py-2 text-center text-sm font-semibold rounded-xl transition-all text-slate-600 hover:text-slate-900 cursor-pointer'"
            >
              Daftar Baru
            </a>
          </div>

          <router-outlet></router-outlet>
        </div>
      </div>
    </div>
  `,
})
export class AuthLayoutComponent implements OnInit {
  constructor(
    public usersService: UsersService,
    private router: Router
  ) {
    effect(() => {
      const isProfile = this.usersService.isProfile();
      if (isProfile) {
        this.usersService.isProfile.set(false);
        if (this.usersService.profile()) {
          this.router.navigate(['/']);
        }
      }
    });
  }

  isLoginActive(): boolean {
    return this.router.url.includes('/auth/login');
  }

  ngOnInit(): void {
    const token = ApiHelper.getAccessToken();
    if (token) {
      this.usersService.asyncSetProfile();
    }
  }
}
