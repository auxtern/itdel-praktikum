import { describe, it, expect, vi, beforeEach } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { AuthLayoutComponent } from './auth-layout.component';
import { UsersService } from '../../../users/services/users.service';
import ApiHelper from '../../../../helpers/api.helper';

describe('AuthLayoutComponent', () => {
  let component: AuthLayoutComponent;
  let usersService: UsersService;
  let router: Router;

  beforeEach(async () => {
    vi.restoreAllMocks();

    await TestBed.configureTestingModule({
      imports: [AuthLayoutComponent],
      providers: [provideRouter([])],
    }).compileComponents();

    usersService = TestBed.inject(UsersService);
    router = TestBed.inject(Router);
    const fixture = TestBed.createComponent(AuthLayoutComponent);
    component = fixture.componentInstance;
  });

  it('should render brand and tabs', () => {
    const fixture = TestBed.createComponent(AuthLayoutComponent);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.textContent).toContain('Delcom Todo');
    expect(el.textContent).toContain('Masuk Akun');
    expect(el.textContent).toContain('Daftar Baru');
  });

  it('should call asyncSetProfile on ngOnInit if token exists', () => {
    vi.spyOn(ApiHelper, 'getAccessToken').mockReturnValue('mock-token');
    const spy = vi.spyOn(usersService, 'asyncSetProfile').mockImplementation(() => Promise.resolve());

    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  it('should not call asyncSetProfile on ngOnInit if token does not exist', () => {
    vi.spyOn(ApiHelper, 'getAccessToken').mockReturnValue(null);
    const spy = vi.spyOn(usersService, 'asyncSetProfile').mockImplementation(() => Promise.resolve());

    component.ngOnInit();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should return true for isLoginActive if router.url contains /auth/login', () => {
    const fixture = TestBed.createComponent(AuthLayoutComponent);
    vi.spyOn(router, 'url', 'get').mockReturnValue('/auth/login');
    expect(component.isLoginActive()).toBe(true);
    fixture.detectChanges();

    vi.spyOn(router, 'url', 'get').mockReturnValue('/auth/register');
    expect(component.isLoginActive()).toBe(false);
    fixture.detectChanges();
  });

  it('should navigate to "/" when isProfile is triggered and profile exists', async () => {
    const navSpy = vi.spyOn(router, 'navigate').mockImplementation(() => Promise.resolve(true));

    usersService.profile.set({ id: 1, name: 'User' } as any);
    usersService.isProfile.set(true);
    TestBed.flushEffects();

    expect(navSpy).toHaveBeenCalledWith(['/']);

    navSpy.mockClear();
    usersService.profile.set(null);
    usersService.isProfile.set(true);
    TestBed.flushEffects();
    expect(navSpy).not.toHaveBeenCalled();
  });
});
