import { describe, it, expect, vi, beforeEach } from 'vitest';
import { UsersService } from './users.service';
import ApiHelper from '../../../helpers/api.helper';
import Swal from 'sweetalert2';

describe('UsersService', () => {
  let service: UsersService;
  const mockUser = {
    id: 1,
    name: 'Abdullah',
    email: 'abdul@delcom.org',
    photo: 'https://example.com/p.jpg',
  };

  beforeEach(() => {
    vi.restoreAllMocks();
    service = new UsersService();
  });

  describe('getUsers', () => {
    it('should return users array on success', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', data: { users: [mockUser] } }), { status: 200 })
      );

      const users = await service.getUsers();
      expect(users).toEqual([mockUser]);
    });

    it('should return empty array if data.users is missing', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', data: {} }), { status: 200 })
      );

      const users = await service.getUsers();
      expect(users).toEqual([]);
    });

    it('should throw error when request fails', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'Unauthorized' }), { status: 401 })
      );

      await expect(service.getUsers()).rejects.toThrow('Unauthorized');
    });

    it('should throw default fallback error when message is empty', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 401 })
      );

      await expect(service.getUsers()).rejects.toThrow('Gagal mengambil data pengguna');
    });
  });

  describe('getUserById', () => {
    it('should return user detail on success', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', data: { user: mockUser } }), { status: 200 })
      );

      const user = await service.getUserById(1);
      expect(user).toEqual(mockUser);
    });

    it('should throw error when request fails', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'User not found' }), { status: 404 })
      );

      await expect(service.getUserById(1)).rejects.toThrow('User not found');
    });

    it('should throw fallback error when message is empty', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 404 })
      );

      await expect(service.getUserById(1)).rejects.toThrow('Gagal mengambil detail pengguna');
    });
  });

  describe('getProfile', () => {
    it('should return profile on success', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', data: { user: mockUser } }), { status: 200 })
      );

      const profile = await service.getProfile();
      expect(profile).toEqual(mockUser);
    });

    it('should throw error when request fails', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'Token expired' }), { status: 401 })
      );

      await expect(service.getProfile()).rejects.toThrow('Token expired');
    });

    it('should throw fallback error when message is empty', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 401 })
      );

      await expect(service.getProfile()).rejects.toThrow('Gagal mengambil data profil');
    });
  });

  describe('putProfile', () => {
    it('should return updated profile on success', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', data: { user: mockUser } }), { status: 200 })
      );

      const updated = await service.putProfile('Updated', 'up@delcom.org');
      expect(updated).toEqual(mockUser);
    });

    it('should throw error when putProfile fails', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'Email in use' }), { status: 400 })
      );

      await expect(service.putProfile('U', 'u@delcom.org')).rejects.toThrow('Email in use');
    });

    it('should throw fallback error when message is empty', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 400 })
      );

      await expect(service.putProfile('U', 'u@delcom.org')).rejects.toThrow('Gagal mengubah profil');
    });
  });

  describe('postProfilePhoto', () => {
    it('should return success message', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', message: 'Foto diupdate' }), { status: 200 })
      );

      const file = new File(['img'], 'photo.png', { type: 'image/png' });
      const msg = await service.postProfilePhoto(file);
      expect(msg).toBe('Foto diupdate');
    });

    it('should throw error on upload failure', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'File too large' }), { status: 400 })
      );

      const file = new File(['img'], '', { type: 'image/png' });
      await expect(service.postProfilePhoto(file)).rejects.toThrow('File too large');
    });

    it('should throw fallback error when message is empty', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 400 })
      );

      const file = new File(['img'], 'p.png', { type: 'image/png' });
      await expect(service.postProfilePhoto(file)).rejects.toThrow('Gagal mengubah foto profil');
    });
  });

  describe('putProfilePassword', () => {
    it('should return success message', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', message: 'Password diubah' }), { status: 200 })
      );

      const msg = await service.putProfilePassword('oldPass', 'newPass', 'newPass');
      expect(msg).toBe('Password diubah');
    });

    it('should handle missing newPasswordConfirmation by defaulting to newPassword', async () => {
      const fetchSpy = vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'success', message: 'OK' }), { status: 200 })
      );

      await service.putProfilePassword('oldPass', 'newPass');
      expect(fetchSpy).toHaveBeenCalled();
    });

    it('should throw error on failure', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: 'Password salah' }), { status: 400 })
      );

      await expect(service.putProfilePassword('wrong', 'newPass')).rejects.toThrow('Password salah');
    });

    it('should throw fallback error when message is empty', async () => {
      vi.spyOn(ApiHelper, 'fetchData').mockResolvedValue(
        new Response(JSON.stringify({ status: 'error', message: '' }), { status: 400 })
      );

      await expect(service.putProfilePassword('wrong', 'newPass')).rejects.toThrow('Gagal mengubah kata sandi');
    });
  });

  describe('asyncSetUsers & asyncSetUserById', () => {
    it('should set users on success and empty array on failure', async () => {
      vi.spyOn(service, 'getUsers').mockResolvedValue([mockUser]);
      await service.asyncSetUsers();
      expect(service.users()).toEqual([mockUser]);

      vi.spyOn(service, 'getUsers').mockRejectedValue(new Error('fail'));
      await service.asyncSetUsers();
      expect(service.users()).toEqual([]);
    });

    it('should set user on success and null on failure', async () => {
      vi.spyOn(service, 'getUserById').mockResolvedValue(mockUser);
      await service.asyncSetUserById(1);
      expect(service.user()).toEqual(mockUser);

      vi.spyOn(service, 'getUserById').mockRejectedValue(new Error('fail'));
      await service.asyncSetUserById(1);
      expect(service.user()).toBeNull();
    });
  });

  describe('asyncSetProfile', () => {
    it('should set profile on success and isProfile true', async () => {
      vi.spyOn(service, 'getProfile').mockResolvedValue(mockUser);
      await service.asyncSetProfile();
      expect(service.profile()).toEqual(mockUser);
      expect(service.isProfile()).toBe(true);
    });

    it('should set profile null on failure and isProfile true', async () => {
      vi.spyOn(service, 'getProfile').mockRejectedValue(new Error('fail'));
      await service.asyncSetProfile();
      expect(service.profile()).toBeNull();
      expect(service.isProfile()).toBe(true);
    });
  });

  describe('asyncPutProfile', () => {
    it('should update profile and show success dialog', async () => {
      vi.spyOn(service, 'putProfile').mockResolvedValue(mockUser);
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncPutProfile('Abdullah', 'abdul@delcom.org');
      expect(service.profile()).toEqual(mockUser);
      expect(service.isChangeProfile()).toBe(true);
      expect(successSpy).toHaveBeenCalled();
    });

    it('should handle failure and show error dialog', async () => {
      vi.spyOn(service, 'putProfile').mockRejectedValue(new Error('Update failed'));
      const errorSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncPutProfile('Abdullah', 'abdul@delcom.org');
      expect(service.isChangeProfile()).toBe(false);
      expect(errorSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Update failed' }));
    });
  });

  describe('asyncPostProfilePhoto', () => {
    it('should update profile photo and refresh profile', async () => {
      vi.spyOn(service, 'postProfilePhoto').mockResolvedValue('Photo ok');
      vi.spyOn(service, 'getProfile').mockResolvedValue(mockUser);
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      const file = new File(['img'], 'pic.png');
      await service.asyncPostProfilePhoto(file);

      expect(service.profile()).toEqual(mockUser);
      expect(service.isChangeProfilePhoto()).toBe(true);
      expect(successSpy).toHaveBeenCalled();
    });

    it('should handle missing message with fallback success string', async () => {
      vi.spyOn(service, 'postProfilePhoto').mockResolvedValue('');
      vi.spyOn(service, 'getProfile').mockResolvedValue(mockUser);
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      const file = new File(['img'], 'pic.png');
      await service.asyncPostProfilePhoto(file);

      expect(successSpy).toHaveBeenCalled();
    });

    it('should handle error dialog on photo failure', async () => {
      vi.spyOn(service, 'postProfilePhoto').mockRejectedValue(new Error('Photo fail'));
      const errorSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      const file = new File(['img'], 'pic.png');
      await service.asyncPostProfilePhoto(file);

      expect(service.isChangeProfilePhoto()).toBe(false);
      expect(errorSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Photo fail' }));
    });
  });

  describe('asyncPutProfilePassword', () => {
    it('should update password and show success dialog', async () => {
      vi.spyOn(service, 'putProfilePassword').mockResolvedValue('Password ok');
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncPutProfilePassword('old', 'new', 'new');
      expect(service.isChangeProfilePassword()).toBe(true);
      expect(successSpy).toHaveBeenCalled();
    });

    it('should handle missing message with fallback string', async () => {
      vi.spyOn(service, 'putProfilePassword').mockResolvedValue('');
      const successSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncPutProfilePassword('old', 'new');
      expect(successSpy).toHaveBeenCalled();
    });

    it('should handle error dialog on password failure', async () => {
      vi.spyOn(service, 'putProfilePassword').mockRejectedValue(new Error('Password fail'));
      const errorSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      await service.asyncPutProfilePassword('old', 'new', 'new');
      expect(service.isChangeProfilePassword()).toBe(false);
      expect(errorSpy).toHaveBeenCalledWith(expect.objectContaining({ text: 'Password fail' }));
    });
  });
});
