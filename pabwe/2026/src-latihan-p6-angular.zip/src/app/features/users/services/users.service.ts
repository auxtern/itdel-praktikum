import { Injectable, signal } from '@angular/core';
import ApiHelper, { BASE_URL } from '../../../helpers/api.helper';
import { showErrorDialog, showSuccessDialog } from '../../../helpers/tools.helper';
import type { User } from '../models/user.model';

@Injectable({
  providedIn: 'root',
})
export class UsersService {
  private usersUrl = `${BASE_URL}/users`;

  users = signal<User[]>([]);
  user = signal<User | null>(null);
  profile = signal<User | null>(null);
  isProfile = signal<boolean>(false);
  isChangeProfile = signal<boolean>(false);
  isChangeProfilePhoto = signal<boolean>(false);
  isChangeProfilePassword = signal<boolean>(false);

  async getUsers(): Promise<User[]> {
    const response = await ApiHelper.fetchData(`${this.usersUrl}/`, {
      method: 'GET',
    });
    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal mengambil data pengguna');
    }
    return result.data?.users || [];
  }

  async getUserById(userId: string | number): Promise<User> {
    const response = await ApiHelper.fetchData(`${this.usersUrl}/${userId}`, {
      method: 'GET',
    });
    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal mengambil detail pengguna');
    }
    return result.data?.user;
  }

  async getProfile(): Promise<User> {
    const response = await ApiHelper.fetchData(`${this.usersUrl}/me`, {
      method: 'GET',
    });
    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal mengambil data profil');
    }
    return result.data?.user;
  }

  async putProfile(name: string, email: string): Promise<User> {
    const response = await ApiHelper.fetchData(`${this.usersUrl}/me`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email }),
    });
    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal mengubah profil');
    }
    return result.data?.user;
  }

  async postProfilePhoto(photo: File): Promise<string> {
    const formData = new FormData();
    formData.append('photo', photo, photo.name || 'profile.png');
    const response = await ApiHelper.fetchData(`${this.usersUrl}/me/photo`, {
      method: 'PUT',
      body: formData,
    });
    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal mengubah foto profil');
    }
    return result.message;
  }

  async putProfilePassword(
    password: string,
    newPassword: string,
    newPasswordConfirmation?: string
  ): Promise<string> {
    const response = await ApiHelper.fetchData(`${this.usersUrl}/password`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        password,
        new_password: newPassword,
        new_password_confirmation: newPasswordConfirmation || newPassword,
      }),
    });
    const result = await response.json();
    if (result.status !== 'success' && !result.success) {
      throw new Error(result.message || 'Gagal mengubah kata sandi');
    }
    return result.message;
  }

  async asyncSetUsers() {
    try {
      const users = await this.getUsers();
      this.users.set(users);
    } catch {
      this.users.set([]);
    }
  }

  async asyncSetUserById(userId: string | number) {
    try {
      const user = await this.getUserById(userId);
      this.user.set(user);
    } catch {
      this.user.set(null);
    }
  }

  async asyncSetProfile() {
    try {
      const profile = await this.getProfile();
      this.profile.set(profile);
    } catch {
      this.profile.set(null);
    } finally {
      this.isProfile.set(true);
    }
  }

  async asyncPutProfile(name: string, email: string) {
    try {
      const profile = await this.putProfile(name, email);
      this.profile.set(profile);
      showSuccessDialog('Profil berhasil diperbarui!');
      this.isChangeProfile.set(true);
    } catch (error: any) {
      showErrorDialog(error.message);
      this.isChangeProfile.set(false);
    }
  }

  async asyncPostProfilePhoto(photo: File) {
    try {
      const message = await this.postProfilePhoto(photo);
      showSuccessDialog(message || 'Foto profil berhasil diperbarui!');
      const profile = await this.getProfile();
      this.profile.set(profile);
      this.isChangeProfilePhoto.set(true);
    } catch (error: any) {
      showErrorDialog(error.message);
      this.isChangeProfilePhoto.set(false);
    }
  }

  async asyncPutProfilePassword(
    oldPassword: string,
    newPassword: string,
    newPasswordConfirmation?: string
  ) {
    try {
      const message = await this.putProfilePassword(
        oldPassword,
        newPassword,
        newPasswordConfirmation
      );
      showSuccessDialog(message || 'Kata sandi berhasil diperbarui!');
      this.isChangeProfilePassword.set(true);
    } catch (error: any) {
      showErrorDialog(error.message);
      this.isChangeProfilePassword.set(false);
    }
  }
}
