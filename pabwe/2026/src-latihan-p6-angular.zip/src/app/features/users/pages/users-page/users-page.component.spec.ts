import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { UsersPageComponent } from './users-page.component';
import { UsersService } from '../../services/users.service';

describe('UsersPageComponent', () => {
  let component: UsersPageComponent;
  let fixture: ComponentFixture<UsersPageComponent>;
  let usersService: UsersService;

  beforeEach(async () => {
    localStorage.clear();
    await TestBed.configureTestingModule({
      imports: [UsersPageComponent],
    }).compileComponents();

    usersService = TestBed.inject(UsersService);
    vi.spyOn(usersService, 'asyncSetUsers').mockResolvedValue(undefined as any);

    fixture = TestBed.createComponent(UsersPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    await fixture.whenStable();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should initialize and load users', async () => {
    fixture.detectChanges();
    await fixture.whenStable();

    expect(component).toBeTruthy();
    expect(usersService.asyncSetUsers).toHaveBeenCalled();
    expect(component.loadingUsers).toBe(false);
  });

  it('should filter users by name and email', () => {
    usersService.users.set([
      { id: 1, name: 'Alice Walker', email: 'alice@example.com' } as any,
      { id: 2, name: 'Bob Dylan', email: 'bob@music.org' } as any,
      { id: 3, name: null, email: null } as any,
    ]);

    // Blank search
    component.search = '   ';
    expect(component.filteredUsers.length).toBe(3);

    // Search by name
    component.search = 'alice';
    expect(component.filteredUsers.length).toBe(1);
    expect(component.filteredUsers[0].id).toBe(1);

    // Search by email
    component.search = 'music.org';
    expect(component.filteredUsers.length).toBe(1);
    expect(component.filteredUsers[0].id).toBe(2);

    // Search with no match
    component.search = 'charlie';
    expect(component.filteredUsers.length).toBe(0);
  });

  it('should return empty list if users is null', () => {
    usersService.users.set(null as any);
    component.search = 'test';
    expect(component.filteredUsers).toEqual([]);
  });

  it('should render loading spinner when loading and no filtered users', () => {
    usersService.users.set([]);
    component.loadingUsers = true;
    fixture.detectChanges();

    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.textContent).toContain('Memuat daftar pengguna...');
  });

  it('should render empty state when not loading and no filtered users', () => {
    usersService.users.set([]);
    component.loadingUsers = false;
    fixture.detectChanges();

    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.textContent).toContain('Tidak ada data pengguna ditemukan.');
  });

  it('should render user cards with photos and avatar initials fallback', () => {
    usersService.users.set([
      {
        id: 1,
        name: 'Alice',
        email: 'alice@example.com',
        photo: 'http://example.com/alice.jpg',
        created_at: '2026-01-01',
      } as any,
      {
        id: 2,
        name: 'Bob',
        email: 'bob@example.com',
        photo: '',
        created_at: '2026-01-01',
      } as any,
      {
        id: 3,
        name: '',
        email: 'nouser@example.com',
        photo: '',
        created_at: '2026-01-01',
      } as any,
    ]);
    fixture.detectChanges();

    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('[data-testid="user-card-1"]')).toBeTruthy();
    expect(compiled.querySelector('[data-testid="user-card-2"]')).toBeTruthy();
    expect(compiled.querySelector('[data-testid="user-card-3"]')).toBeTruthy();

    const img = compiled.querySelector('[data-testid="user-card-1"] img') as HTMLImageElement;
    expect(img.src).toBe('http://example.com/alice.jpg');

    expect(compiled.querySelector('[data-testid="user-card-2"]')?.textContent).toContain('B');
    expect(compiled.querySelector('[data-testid="user-card-3"]')?.textContent).toContain('U');
  });

  it('should update search via ngModelChange in template', () => {
    const searchDe = fixture.debugElement.query(By.css('[data-testid="search-user-input"]'));
    searchDe?.triggerEventHandler('ngModelChange', 'searched');
    expect(component.search).toBe('searched');
  });
});
