import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UsersService } from '../../services/users.service';
import { formatDate } from '../../../../helpers/tools.helper';
import type { User } from '../../models/user.model';

@Component({
  selector: 'app-users-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="space-y-6 animate-in fade-in duration-300">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Semua Pengguna
          </h1>
          <p class="text-sm text-slate-500 mt-1">
            Daftar seluruh akun pengguna yang terdaftar di dalam sistem.
          </p>
        </div>
      </div>

      <div class="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <!-- Header Search -->
        <div class="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between gap-4">
          <div class="relative flex-1 max-w-md">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
            <input
              type="text"
              data-testid="search-user-input"
              [(ngModel)]="search"
              placeholder="Cari pengguna berdasarkan nama atau email..."
              class="w-full pl-10 pr-4 py-2 text-sm rounded-xl border border-slate-200 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
            />
          </div>
          <span class="text-xs font-semibold text-slate-500 px-3 py-1 bg-slate-100 rounded-lg">
            Total: {{ filteredUsers.length }} Pengguna
          </span>
        </div>

        <!-- User Grid -->
        <div class="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          @if (loadingUsers && filteredUsers.length === 0) {
            <div class="col-span-full py-16 text-center text-slate-400">
              <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mx-auto text-indigo-600 animate-spin mb-2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
              <p class="font-medium text-slate-600">Memuat daftar pengguna...</p>
            </div>
          } @else if (filteredUsers.length === 0) {
            <div class="col-span-full py-12 text-center text-slate-400">
              <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mx-auto text-slate-300 mb-2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              <p class="font-medium">Tidak ada data pengguna ditemukan.</p>
            </div>
          } @else {
            @for (u of filteredUsers; track u.id) {
              <div
                [attr.data-testid]="'user-card-' + u.id"
                class="p-5 rounded-2xl border border-slate-200/80 hover:border-indigo-300 hover:shadow-md transition-all bg-white flex flex-col justify-between"
              >
                <div class="flex items-start gap-3.5">
                  @if (u.photo) {
                    <img
                      [src]="u.photo"
                      [alt]="u.name"
                      class="w-12 h-12 rounded-full object-cover border border-slate-200 shrink-0"
                    />
                  } @else {
                    <div class="w-12 h-12 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 text-white flex items-center justify-center font-bold text-base shrink-0">
                      {{ u.name ? u.name.charAt(0).toUpperCase() : 'U' }}
                    </div>
                  }

                  <div class="min-w-0 flex-1">
                    <h3 class="font-bold text-slate-900 truncate">{{ u.name }}</h3>
                    <p class="text-xs text-slate-500 flex items-center gap-1 mt-0.5 truncate">
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="shrink-0 text-slate-400"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                      <span class="truncate">{{ u.email }}</span>
                    </p>
                  </div>
                </div>

                <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                  <span class="font-mono font-semibold">ID: #{{ u.id }}</span>
                  <span class="flex items-center gap-1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg>
                    {{ formatDate(u.created_at) }}
                  </span>
                </div>
              </div>
            }
          }
        </div>
      </div>
    </div>
  `,
})
export class UsersPageComponent implements OnInit {
  loadingUsers = false;
  search = '';
  formatDate = formatDate;

  constructor(public usersService: UsersService) {}

  ngOnInit(): void {
    this.loadingUsers = true;
    this.usersService.asyncSetUsers().finally(() => {
      this.loadingUsers = false;
    });
  }

  get filteredUsers(): User[] {
    const users = this.usersService.users() || [];
    if (!this.search.trim()) return users;
    const query = this.search.toLowerCase();
    return users.filter((u) => {
      const nameMatch = u.name ? u.name.toLowerCase().includes(query) : false;
      const emailMatch = u.email ? u.email.toLowerCase().includes(query) : false;
      return nameMatch || emailMatch;
    });
  }
}
