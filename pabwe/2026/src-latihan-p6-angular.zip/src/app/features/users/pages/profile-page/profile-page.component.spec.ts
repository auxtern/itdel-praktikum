import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ProfilePageComponent } from './profile-page.component';
import { UsersService } from '../../services/users.service';
import Swal from 'sweetalert2';

describe('ProfilePageComponent', () => {
  let component: ProfilePageComponent;
  let fixture: ComponentFixture<ProfilePageComponent>;
  let usersService: UsersService;

  beforeEach(async () => {
    localStorage.clear();
    await TestBed.configureTestingModule({
      imports: [ProfilePageComponent],
    }).compileComponents();

    usersService = TestBed.inject(UsersService);
    vi.spyOn(usersService, 'asyncPutProfile').mockResolvedValue(undefined as any);
    vi.spyOn(usersService, 'asyncPostProfilePhoto').mockResolvedValue(undefined as any);
    vi.spyOn(usersService, 'asyncPutProfilePassword').mockResolvedValue(undefined as any);

    usersService.profile.set({
      id: 1,
      name: 'John Doe',
      email: 'john@example.com',
      photo: 'http://example.com/avatar.jpg',
    } as any);

    fixture = TestBed.createComponent(ProfilePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should initialize and populate name and email from profile', () => {
    expect(component).toBeTruthy();
    expect(component.name).toBe('John Doe');
    expect(component.email).toBe('john@example.com');
  });

  it('should handle null fields in profile effect', () => {
    usersService.profile.set({
      id: 2,
      name: null as any,
      email: null as any,
      photo: null as any,
    } as any);
    TestBed.flushEffects();

    expect(component.name).toBe('');
    expect(component.email).toBe('');
  });

  it('should render loading state when profile is null', () => {
    usersService.profile.set(null);
    fixture.detectChanges();

    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.textContent).toContain('Memuat data profil...');
  });

  it('should validate and update profile biodata', () => {
    const swalSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({} as any);

    // Empty name
    component.name = '   ';
    component.email = 'valid@example.com';
    component.handleUpdateProfile();
    expect(swalSpy).toHaveBeenCalledWith(expect.objectContaining({
      text: 'Nama tidak boleh kosong!',
    }));
    expect(usersService.asyncPutProfile).not.toHaveBeenCalled();

    // Empty email
    component.name = 'Valid Name';
    component.email = '   ';
    component.handleUpdateProfile();
    expect(swalSpy).toHaveBeenCalledWith(expect.objectContaining({
      text: 'Email tidak boleh kosong!',
    }));
    expect(usersService.asyncPutProfile).not.toHaveBeenCalled();

    // Valid submission
    component.name = 'Valid Name';
    component.email = 'valid@example.com';
    component.handleUpdateProfile();
    expect(component.loadingProfile).toBe(true);
    fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('Menyimpan Perubahan...');
    expect(usersService.asyncPutProfile).toHaveBeenCalledWith('Valid Name', 'valid@example.com');
  });

  it('should validate and handle photo upload', () => {
    const swalSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({} as any);

    // No file selected
    component.handlePhotoUpload({ target: { files: [] } } as any);
    expect(usersService.asyncPostProfilePhoto).not.toHaveBeenCalled();

    // Invalid file type
    const textFile = new File(['hello'], 'hello.txt', { type: 'text/plain' });
    component.handlePhotoUpload({ target: { files: [textFile] } } as any);
    expect(swalSpy).toHaveBeenCalledWith(expect.objectContaining({
      text: 'Pilih file gambar yang valid!',
    }));

    // File too large (> 3MB)
    const largeContent = new Uint8Array(4 * 1024 * 1024);
    const largeFile = new File([largeContent], 'large.png', { type: 'image/png' });
    component.handlePhotoUpload({ target: { files: [largeFile] } } as any);
    expect(swalSpy).toHaveBeenCalledWith(expect.objectContaining({
      text: 'Ukuran file foto maksimal 3MB!',
    }));

    // Valid image file
    const validFile = new File(['valid'], 'avatar.png', { type: 'image/png' });
    component.handlePhotoUpload({ target: { files: [validFile] } } as any);
    expect(component.loadingPhoto).toBe(true);
    fixture.detectChanges();
    expect(usersService.asyncPostProfilePhoto).toHaveBeenCalledWith(validFile);

    const fileInput = fixture.nativeElement.querySelector('[data-testid="profile-photo-file-input"]') as HTMLInputElement;
    fileInput?.dispatchEvent(new Event('change'));
  });

  it('should validate and update password', () => {
    const swalSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({} as any);

    // Missing old password
    component.oldPassword = '';
    component.handleUpdatePassword();
    expect(swalSpy).toHaveBeenCalledWith(expect.objectContaining({
      text: 'Kata sandi lama wajib diisi!',
    }));

    // Short new password
    component.oldPassword = 'oldpass';
    component.newPassword = '123';
    component.handleUpdatePassword();
    expect(swalSpy).toHaveBeenCalledWith(expect.objectContaining({
      text: 'Kata sandi baru minimal 6 karakter!',
    }));

    // Password confirmation mismatch
    component.newPassword = 'password123';
    component.newPasswordConfirmation = 'password456';
    component.handleUpdatePassword();
    expect(swalSpy).toHaveBeenCalledWith(expect.objectContaining({
      text: 'Konfirmasi kata sandi tidak cocok!',
    }));

    // Valid update
    component.newPasswordConfirmation = 'password123';
    component.handleUpdatePassword();
    expect(component.loadingPassword).toBe(true);
    fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('Memperbarui Password...');
    expect(usersService.asyncPutProfilePassword).toHaveBeenCalledWith(
      'oldpass',
      'password123',
      'password123'
    );
  });

  it('should react to isChangeProfile signal effect or false branch', () => {
    // false branch
    usersService.isChangeProfile.set(false);
    TestBed.flushEffects();

    component.loadingProfile = true;
    usersService.isChangeProfile.set(true);
    TestBed.flushEffects();

    expect(component.loadingProfile).toBe(false);
    expect(usersService.isChangeProfile()).toBe(false);
  });

  it('should react to isChangeProfilePhoto signal effect or false branch', () => {
    // false branch
    usersService.isChangeProfilePhoto.set(false);
    TestBed.flushEffects();

    component.loadingPhoto = true;
    usersService.isChangeProfilePhoto.set(true);
    TestBed.flushEffects();

    expect(component.loadingPhoto).toBe(false);
    expect(usersService.isChangeProfilePhoto()).toBe(false);
  });

  it('should react to isChangeProfilePassword signal effect or false branch', () => {
    // false branch
    usersService.isChangeProfilePassword.set(false);
    TestBed.flushEffects();

    component.loadingPassword = true;
    component.oldPassword = 'old';
    component.newPassword = 'new';
    component.newPasswordConfirmation = 'new';

    usersService.isChangeProfilePassword.set(true);
    TestBed.flushEffects();

    expect(component.loadingPassword).toBe(false);
    expect(usersService.isChangeProfilePassword()).toBe(false);
    expect(component.oldPassword).toBe('');
    expect(component.newPassword).toBe('');
    expect(component.newPasswordConfirmation).toBe('');
  });

  it('should render avatar initial fallback when photo is null or empty, and handle truthy name with null photo', () => {
    usersService.profile.set({
      id: 1,
      name: '',
      email: 'john@example.com',
      photo: '',
    } as any);
    fixture.detectChanges();

    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('img')).toBeNull();
    expect(compiled.textContent).toContain('U');

    // Truthy name with null photo
    usersService.profile.set({
      id: 3,
      name: 'Alice',
      email: 'alice@example.com',
      photo: null,
    } as any);
    fixture.detectChanges();
    expect(compiled.textContent).toContain('A');
  });

  it('should update inputs via ngModelChange and submit forms', () => {
    fixture.detectChanges();
    const nameDe = fixture.debugElement.query(By.css('#profile-name-input'));
    nameDe?.triggerEventHandler('ngModelChange', 'Updated Name');
    expect(component.name).toBe('Updated Name');

    const emailDe = fixture.debugElement.query(By.css('#profile-email-input'));
    emailDe?.triggerEventHandler('ngModelChange', 'updated@email.com');
    expect(component.email).toBe('updated@email.com');

    const forms = fixture.debugElement.queryAll(By.css('form'));
    const updateProfileSpy = vi.spyOn(component, 'handleUpdateProfile');
    forms[0]?.triggerEventHandler('ngSubmit', null);
    expect(updateProfileSpy).toHaveBeenCalled();

    const oldPassDe = fixture.debugElement.query(By.css('#current-password-input'));
    oldPassDe?.triggerEventHandler('ngModelChange', 'pass123');
    expect(component.oldPassword).toBe('pass123');

    const newPassDe = fixture.debugElement.query(By.css('#new-password-input'));
    newPassDe?.triggerEventHandler('ngModelChange', 'newpass123');
    expect(component.newPassword).toBe('newpass123');

    const confirmPassDe = fixture.debugElement.query(By.css('#confirm-password-input'));
    confirmPassDe?.triggerEventHandler('ngModelChange', 'newpass123');
    expect(component.newPasswordConfirmation).toBe('newpass123');

    const updatePassSpy = vi.spyOn(component, 'handleUpdatePassword');
    forms[1]?.triggerEventHandler('ngSubmit', null);
    expect(updatePassSpy).toHaveBeenCalled();
  });
});
