import { Component, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UsersService } from '../../services/users.service';
import { showErrorDialog } from '../../../../helpers/tools.helper';

@Component({
  selector: 'app-profile-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    @if (!usersService.profile()) {
      <div class="flex flex-col items-center justify-center py-24">
        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-indigo-600 animate-spin mb-2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
        <p class="text-sm font-medium text-slate-600">Memuat data profil...</p>
      </div>
    } @else {
      @let profile = usersService.profile()!;
      <div class="space-y-8 max-w-4xl mx-auto animate-in fade-in duration-300">
        <div>
          <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Profil Akun
          </h1>
          <p class="text-sm text-slate-500 mt-1">
            Kelola informasi identitas, foto profil, dan keamanan akun Anda.
          </p>
        </div>

        <!-- Profile Card Header -->
        <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center gap-6">
          <div class="relative group">
            @if (profile.photo) {
              <img
                [src]="profile.photo"
                [alt]="profile.name"
                class="w-24 h-24 rounded-full object-cover border-4 border-white shadow-md ring-2 ring-indigo-100"
              />
            } @else {
              <div class="w-24 h-24 rounded-full bg-gradient-to-tr from-indigo-600 to-cyan-500 text-white flex items-center justify-center font-bold text-3xl shadow-md">
                {{ profile.name ? profile.name.charAt(0).toUpperCase() : 'U' }}
              </div>
            }

            <label
              data-testid="upload-profile-photo-btn"
              class="absolute bottom-0 right-0 p-2 rounded-full bg-indigo-600 hover:bg-indigo-700 text-white shadow-md cursor-pointer transition-transform hover:scale-105"
              title="Ubah Foto Profil"
            >
              @if (loadingPhoto) {
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
              } @else {
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>
              }
              <input
                type="file"
                data-testid="profile-photo-file-input"
                accept="image/*"
                (change)="handlePhotoUpload($event)"
                class="hidden"
              />
            </label>
          </div>

          <div class="text-center sm:text-left space-y-1">
            <h2 class="text-xl font-bold text-slate-800">{{ profile.name }}</h2>
            <p class="text-sm text-slate-500">{{ profile.email }}</p>
            <div class="pt-2">
              <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/60">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                Terverifikasi
              </span>
            </div>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <!-- Form Biodata -->
          <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs space-y-5">
            <div class="flex items-center gap-2.5 pb-2 border-b border-slate-100">
              <div class="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              </div>
              <h3 class="font-bold text-slate-800">Ubah Biodata</h3>
            </div>

            <form (ngSubmit)="handleUpdateProfile()" class="space-y-4">
              <div>
                <label for="profile-name-input" class="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                  Nama Lengkap
                </label>
                <input
                  id="profile-name-input"
                  type="text"
                  data-testid="profile-name-input"
                  [(ngModel)]="name"
                  name="name"
                  class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                  required
                />
              </div>

              <div>
                <label for="profile-email-input" class="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                  Alamat Email
                </label>
                <input
                  id="profile-email-input"
                  type="email"
                  data-testid="profile-email-input"
                  [(ngModel)]="email"
                  name="email"
                  class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                  required
                />
              </div>

              <div class="pt-2">
                <button
                  type="submit"
                  data-testid="submit-profile-btn"
                  [disabled]="loadingProfile"
                  class="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-xl shadow-md shadow-indigo-600/25 transition-all disabled:opacity-60 cursor-pointer"
                >
                  @if (loadingProfile) {
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                    <span>Menyimpan Perubahan...</span>
                  } @else {
                    <span>Simpan Perubahan</span>
                  }
                </button>
              </div>
            </form>
          </div>

          <!-- Form Ganti Password -->
          <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs space-y-5">
            <div class="flex items-center gap-2.5 pb-2 border-b border-slate-100">
              <div class="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>
              </div>
              <h3 class="font-bold text-slate-800">Keamanan & Password</h3>
            </div>

            <form (ngSubmit)="handleUpdatePassword()" class="space-y-4">
              <div>
                <label for="current-password-input" class="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                  Kata Sandi Saat Ini
                </label>
                <input
                  id="current-password-input"
                  type="password"
                  data-testid="current-password-input"
                  [(ngModel)]="oldPassword"
                  name="oldPassword"
                  placeholder="••••••"
                  class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                  required
                />
              </div>

              <div>
                <label for="new-password-input" class="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                  Kata Sandi Baru
                </label>
                <input
                  id="new-password-input"
                  type="password"
                  data-testid="new-password-input"
                  [(ngModel)]="newPassword"
                  name="newPassword"
                  placeholder="Minimal 6 karakter"
                  class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                  required
                />
              </div>

              <div>
                <label for="confirm-password-input" class="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                  Ulangi Kata Sandi Baru
                </label>
                <input
                  id="confirm-password-input"
                  type="password"
                  data-testid="confirm-password-input"
                  [(ngModel)]="newPasswordConfirmation"
                  name="newPasswordConfirmation"
                  placeholder="Konfirmasi kata sandi"
                  class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                  required
                />
              </div>

              <div class="pt-2">
                <button
                  type="submit"
                  data-testid="submit-password-btn"
                  [disabled]="loadingPassword"
                  class="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 active:bg-slate-950 rounded-xl shadow-md transition-all disabled:opacity-60 cursor-pointer"
                >
                  @if (loadingPassword) {
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                    <span>Memperbarui Password...</span>
                  } @else {
                    <span>Perbarui Password</span>
                  }
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    }
  `,
})
export class ProfilePageComponent {
  name = '';
  email = '';
  oldPassword = '';
  newPassword = '';
  newPasswordConfirmation = '';

  loadingProfile = false;
  loadingPhoto = false;
  loadingPassword = false;

  constructor(public usersService: UsersService) {
    effect(() => {
      const profile = this.usersService.profile();
      if (profile) {
        this.name = profile.name || '';
        this.email = profile.email || '';
      }
    });

    effect(() => {
      const isChangeProfile = this.usersService.isChangeProfile();
      if (isChangeProfile) {
        this.loadingProfile = false;
        this.usersService.isChangeProfile.set(false);
      }
    });

    effect(() => {
      const isChangeProfilePhoto = this.usersService.isChangeProfilePhoto();
      if (isChangeProfilePhoto) {
        this.loadingPhoto = false;
        this.usersService.isChangeProfilePhoto.set(false);
      }
    });

    effect(() => {
      const isChangeProfilePassword = this.usersService.isChangeProfilePassword();
      if (isChangeProfilePassword) {
        this.loadingPassword = false;
        this.usersService.isChangeProfilePassword.set(false);
        this.oldPassword = '';
        this.newPassword = '';
        this.newPasswordConfirmation = '';
      }
    });
  }

  handleUpdateProfile(): void {
    if (!this.name.trim()) {
      showErrorDialog('Nama tidak boleh kosong!');
      return;
    }
    if (!this.email.trim()) {
      showErrorDialog('Email tidak boleh kosong!');
      return;
    }
    this.loadingProfile = true;
    this.usersService.asyncPutProfile(this.name.trim(), this.email.trim());
  }

  handlePhotoUpload(e: Event): void {
    const target = e.target as HTMLInputElement;
    const file = target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showErrorDialog('Pilih file gambar yang valid!');
      return;
    }

    if (file.size > 3 * 1024 * 1024) {
      showErrorDialog('Ukuran file foto maksimal 3MB!');
      return;
    }

    this.loadingPhoto = true;
    this.usersService.asyncPostProfilePhoto(file);
  }

  handleUpdatePassword(): void {
    if (!this.oldPassword) {
      showErrorDialog('Kata sandi lama wajib diisi!');
      return;
    }
    if (!this.newPassword || this.newPassword.length < 6) {
      showErrorDialog('Kata sandi baru minimal 6 karakter!');
      return;
    }
    if (this.newPassword !== this.newPasswordConfirmation) {
      showErrorDialog('Konfirmasi kata sandi tidak cocok!');
      return;
    }

    this.loadingPassword = true;
    this.usersService.asyncPutProfilePassword(
      this.oldPassword,
      this.newPassword,
      this.newPasswordConfirmation
    );
  }
}
