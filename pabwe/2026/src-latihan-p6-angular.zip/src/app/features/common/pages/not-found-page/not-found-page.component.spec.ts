import { describe, it, expect, vi, beforeEach } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { NotFoundPageComponent } from './not-found-page.component';

describe('NotFoundPageComponent', () => {
  let component: NotFoundPageComponent;
  let mockRouter: any;

  beforeEach(async () => {
    mockRouter = {
      navigate: vi.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [NotFoundPageComponent],
      providers: [{ provide: Router, useValue: mockRouter }],
    }).compileComponents();

    const fixture = TestBed.createComponent(NotFoundPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create and render 404 message', () => {
    expect(component).toBeTruthy();
    const fixture = TestBed.createComponent(NotFoundPageComponent);
    const element = fixture.nativeElement as HTMLElement;
    expect(element.textContent).toContain('404');
    expect(element.textContent).toContain('Halaman Tidak Ditemukan');
  });

  it('should navigate home when goHome is called or home button clicked', () => {
    const fixture = TestBed.createComponent(NotFoundPageComponent);
    fixture.detectChanges();
    const btn = fixture.nativeElement.querySelector('[data-testid="home-button"]') as HTMLButtonElement;
    btn.click();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/']);
  });

  it('should call window.history.back on goBack or back button clicked', () => {
    const backSpy = vi.spyOn(window.history, 'back').mockImplementation(() => {});
    const fixture = TestBed.createComponent(NotFoundPageComponent);
    fixture.detectChanges();
    const btn = fixture.nativeElement.querySelector('[data-testid="back-button"]') as HTMLButtonElement;
    btn.click();
    expect(backSpy).toHaveBeenCalled();
  });
});
