import { describe, it, expect, beforeEach, vi } from 'vitest';
import { ApiHelper, BASE_URL } from './api.helper';

describe('ApiHelper', () => {
  beforeEach(() => {
    localStorage.clear();
    vi.restoreAllMocks();
  });

  it('should export BASE_URL', () => {
    expect(BASE_URL).toBe('https://open-api.delcom.org/api/v1');
  });

  it('should get and put access token', () => {
    expect(ApiHelper.getAccessToken()).toBeNull();
    ApiHelper.putAccessToken('my-token');
    expect(ApiHelper.getAccessToken()).toBe('my-token');
    ApiHelper.putAccessToken('');
    expect(ApiHelper.getAccessToken()).toBeNull();
  });

  it('should handle localStorage undefined safely', () => {
    const originalLocalStorage = globalThis.localStorage;
    Object.defineProperty(globalThis, 'localStorage', {
      value: undefined,
      configurable: true,
      writable: true,
    });

    expect(ApiHelper.getAccessToken()).toBeNull();
    expect(() => ApiHelper.putAccessToken('token')).not.toThrow();

    Object.defineProperty(globalThis, 'localStorage', {
      value: originalLocalStorage,
      configurable: true,
      writable: true,
    });
  });

  it('should fetchData with authorization header when token exists and normalize trailing slash', async () => {
    ApiHelper.putAccessToken('valid-token');
    const mockResponse = new Response(JSON.stringify({ ok: true }), { status: 200 });
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValue(mockResponse);

    const res = await ApiHelper.fetchData('https://api.example.com/todos/?filter=active', {
      method: 'GET',
      headers: { 'Custom-Header': 'val' },
    });

    expect(fetchSpy).toHaveBeenCalledWith('https://api.example.com/todos?filter=active', {
      method: 'GET',
      mode: 'cors',
      headers: {
        'Custom-Header': 'val',
        Authorization: 'Bearer valid-token',
      },
    });
    expect(res).toBe(mockResponse);
  });

  it('should fetchData without authorization header when no token exists and no query string', async () => {
    const mockResponse = new Response(JSON.stringify({ ok: true }), { status: 200 });
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValue(mockResponse);

    await ApiHelper.fetchData('https://api.example.com/todos');

    expect(fetchSpy).toHaveBeenCalledWith('https://api.example.com/todos', {
      mode: 'cors',
      headers: {},
    });
  });
});
