import { describe, it, expect, vi, beforeEach } from 'vitest';
import Swal from 'sweetalert2';
import {
  showErrorDialog,
  showWarningDialog,
  showSuccessDialog,
  showConfirmDialog,
  formatDate,
} from './tools.helper';

describe('tools.helper', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  describe('showErrorDialog', () => {
    it('should invoke Swal.fire with error configuration and handle confirmation', async () => {
      const fireSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);
      const closeSpy = vi.spyOn(Swal, 'close').mockImplementation(() => {});

      const result = await showErrorDialog('Error message');

      expect(fireSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          title: 'Terjadi Kesalahan',
          text: 'Error message',
          icon: 'error',
        })
      );
      expect(closeSpy).toHaveBeenCalled();
      expect(result.isConfirmed).toBe(true);
    });

    it('should not call Swal.close if not confirmed', async () => {
      vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: false } as any);
      const closeSpy = vi.spyOn(Swal, 'close').mockImplementation(() => {});

      const result = await showErrorDialog('Error message');
      expect(closeSpy).not.toHaveBeenCalled();
      expect(result.isConfirmed).toBe(false);
    });
  });

  describe('showWarningDialog', () => {
    it('should invoke Swal.fire with warning configuration and handle confirmation', async () => {
      const fireSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);
      const closeSpy = vi.spyOn(Swal, 'close').mockImplementation(() => {});

      const result = await showWarningDialog('Warning message');

      expect(fireSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          title: 'Peringatan',
          text: 'Warning message',
          icon: 'warning',
        })
      );
      expect(closeSpy).toHaveBeenCalled();
      expect(result.isConfirmed).toBe(true);
    });

    it('should not call Swal.close if not confirmed', async () => {
      vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: false } as any);
      const closeSpy = vi.spyOn(Swal, 'close').mockImplementation(() => {});

      const result = await showWarningDialog('Warning message');
      expect(closeSpy).not.toHaveBeenCalled();
      expect(result.isConfirmed).toBe(false);
    });
  });

  describe('showSuccessDialog', () => {
    it('should invoke Swal.fire with success configuration and handle confirmation', async () => {
      const fireSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);
      const closeSpy = vi.spyOn(Swal, 'close').mockImplementation(() => {});

      const result = await showSuccessDialog('Success message');

      expect(fireSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          title: 'Tindakan Berhasil',
          text: 'Success message',
          icon: 'success',
        })
      );
      expect(closeSpy).toHaveBeenCalled();
      expect(result.isConfirmed).toBe(true);
    });

    it('should not call Swal.close if not confirmed', async () => {
      vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: false } as any);
      const closeSpy = vi.spyOn(Swal, 'close').mockImplementation(() => {});

      const result = await showSuccessDialog('Success message');
      expect(closeSpy).not.toHaveBeenCalled();
      expect(result.isConfirmed).toBe(false);
    });
  });

  describe('showConfirmDialog', () => {
    it('should invoke Swal.fire with confirm options', async () => {
      const fireSpy = vi.spyOn(Swal, 'fire').mockResolvedValue({ isConfirmed: true } as any);

      const res = await showConfirmDialog('Yakin hapus?');

      expect(fireSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          title: 'Konfirmasi',
          text: 'Yakin hapus?',
          icon: 'question',
          showCancelButton: true,
        })
      );
      expect(res.isConfirmed).toBe(true);
    });
  });

  describe('formatDate', () => {
    it('should return "-" when input is null or undefined or empty', () => {
      expect(formatDate(null)).toBe('-');
      expect(formatDate(undefined)).toBe('-');
      expect(formatDate('')).toBe('-');
    });

    it('should format valid date string correctly', () => {
      const result = formatDate('2026-02-26T02:34:26.000000Z');
      expect(result).toBeDefined();
      expect(typeof result).toBe('string');
      expect(result).not.toBe('-');
    });
  });
});
