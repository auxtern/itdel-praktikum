export const BASE_URL = 'https://open-api.delcom.org/api/v1';

export class ApiHelper {
  static getAccessToken(): string | null {
    if (typeof localStorage === 'undefined') return null;
    return localStorage.getItem('accessToken');
  }

  static putAccessToken(token: string): void {
    if (typeof localStorage === 'undefined') return;
    if (!token) {
      localStorage.removeItem('accessToken');
    } else {
      localStorage.setItem('accessToken', token);
    }
  }

  static async fetchData(url: string, options: RequestInit = {}): Promise<Response> {
    const urlQuery = url.includes('?') ? url.split('?')[1] : '';
    const urlWithoutQuery = url.replace(`?${urlQuery}`, '');
    const fixUrl = urlWithoutQuery.endsWith('/')
      ? urlWithoutQuery.slice(0, -1)
      : urlWithoutQuery;
    const fullUrl = fixUrl + (urlQuery ? `?${urlQuery}` : '');

    const token = this.getAccessToken();
    const headers: Record<string, string> = {
      ...((options.headers as Record<string, string>) || {}),
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    return fetch(fullUrl, {
      ...options,
      mode: 'cors',
      headers,
    });
  }
}

export default ApiHelper;
