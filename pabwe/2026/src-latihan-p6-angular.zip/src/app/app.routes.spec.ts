import { routes } from './app.routes';
import { AuthLayoutComponent } from './features/auth/layouts/auth-layout/auth-layout.component';
import { LoginPageComponent } from './features/auth/pages/login-page/login-page.component';
import { RegisterPageComponent } from './features/auth/pages/register-page/register-page.component';
import { TodoLayoutComponent } from './features/todos/layouts/todo-layout/todo-layout.component';
import { HomePageComponent } from './features/todos/pages/home-page/home-page.component';
import { DetailPageComponent } from './features/todos/pages/detail-page/detail-page.component';
import { UsersPageComponent } from './features/users/pages/users-page/users-page.component';
import { ProfilePageComponent } from './features/users/pages/profile-page/profile-page.component';
import { NotFoundPageComponent } from './features/common/pages/not-found-page/not-found-page.component';

describe('routes', () => {
  it('should define app routes correctly', () => {
    expect(routes).toBeDefined();
    expect(routes.length).toBe(3);

    // Auth route
    const authRoute = routes.find((r) => r.path === 'auth');
    expect(authRoute).toBeDefined();
    expect(authRoute?.component).toBe(AuthLayoutComponent);
    expect(authRoute?.children?.length).toBe(3);
    expect(authRoute?.children?.[0].component).toBe(LoginPageComponent);
    expect(authRoute?.children?.[1].component).toBe(RegisterPageComponent);
    expect(authRoute?.children?.[2].redirectTo).toBe('login');

    // Main / Todo route
    const mainRoute = routes.find((r) => r.path === '');
    expect(mainRoute).toBeDefined();
    expect(mainRoute?.component).toBe(TodoLayoutComponent);
    expect(mainRoute?.children?.length).toBe(4);
    expect(mainRoute?.children?.[0].component).toBe(HomePageComponent);
    expect(mainRoute?.children?.[1].component).toBe(DetailPageComponent);
    expect(mainRoute?.children?.[2].component).toBe(UsersPageComponent);
    expect(mainRoute?.children?.[3].component).toBe(ProfilePageComponent);

    // Wildcard route
    const wildcardRoute = routes.find((r) => r.path === '**');
    expect(wildcardRoute).toBeDefined();
    expect(wildcardRoute?.component).toBe(NotFoundPageComponent);
  });
});
