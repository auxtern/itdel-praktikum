const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

function loadPortFromEnv() {
  const envPath = path.resolve(process.cwd(), '.env');
  if (fs.existsSync(envPath)) {
    const content = fs.readFileSync(envPath, 'utf8');
    const lines = content.split(/\r?\n/);
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const match = trimmed.match(/^APP_PORT\s*=\s*(["']?)(.*?)\1(?:\s*#.*)?$/);
      if (match && match[2]) {
        const parsed = parseInt(match[2].trim(), 10);
        if (!isNaN(parsed) && parsed > 0) {
          return parsed;
        }
      }
    }
  }
  return null;
}

const envPort = process.env.APP_PORT ? parseInt(process.env.APP_PORT, 10) : null;
const port = (!isNaN(envPort) && envPort > 0 ? envPort : null) || loadPortFromEnv() || 3001;

const userArgs = process.argv.slice(2);
const hasPortArg = userArgs.some((arg) => arg === '--port' || arg.startsWith('--port='));

const ngArgs = ['serve'];
if (!hasPortArg) {
  ngArgs.push('--port', String(port));
}
ngArgs.push(...userArgs);

const ngBin = require.resolve('@angular/cli/bin/ng.js');

const child = spawn(process.execPath, [ngBin, ...ngArgs], {
  stdio: 'inherit',
  env: process.env,
});

child.on('exit', (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
  } else {
    process.exit(code ?? 0);
  }
});
