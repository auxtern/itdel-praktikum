import { describe, it, expect } from "vitest";
import App from "./App";
import { renderWithProviders } from "./test-utils";

describe("App Component", () => {
  it("should render application without crashing", () => {
    const { container } = renderWithProviders(<App />);
    expect(container).toBeDefined();
  });
});
